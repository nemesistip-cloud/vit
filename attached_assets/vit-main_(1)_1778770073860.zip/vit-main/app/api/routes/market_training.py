"""
app/api/routes/market_training.py — Phase 2: Specialized Market Model Training Routes

POST /api/market-training/train          — train all three market models
POST /api/market-training/train/btts     — train BTTS model only
POST /api/market-training/train/ou       — train Over/Under model only
POST /api/market-training/train/cs       — train Correct Score model only
GET  /api/market-training/status         — list saved models + sizes
"""

import logging
import os
from typing import Optional

from fastapi import APIRouter, BackgroundTasks, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_admin
from app.auth.dependencies import get_current_user
from app.db.database import get_db
from app.db.models import User

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/market-training", tags=["Market Model Training"])

_MODELS_DIR = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "..", "..", "models")
)

# ── In-memory job status ──────────────────────────────────────────────────────

_job_status: dict = {}


def _job_key(market: str) -> str:
    return f"market_train_{market}"


async def _run_and_record(market: str, coro):
    key = _job_key(market)
    _job_status[key] = {"status": "running", "market": market}
    try:
        result = await coro
        _job_status[key] = {"status": "done", "market": market, "result": result}
        logger.info("[market-training] %s completed: %s", market, result)
    except Exception as exc:
        _job_status[key] = {"status": "error", "market": market, "error": str(exc)}
        logger.error("[market-training] %s failed: %s", market, exc)


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.post("/train", summary="Train all three market models (async)")
async def train_all(
    background_tasks: BackgroundTasks,
    epochs: int = 60,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_admin),
):
    """
    Launch training jobs for BTTS, Over/Under, and Correct Score models.
    Training runs in the background — poll /status for progress.
    """
    from app.ai.market_trainer import (
        train_btts_model,
        train_over_under_model,
        train_correct_score_model,
    )

    async def _all(db=db, epochs=epochs):
        from app.ai.market_trainer import train_all_market_models
        async with __import__("app.db.database", fromlist=["AsyncSessionLocal"]).AsyncSessionLocal() as _db:
            return await train_all_market_models(_db, epochs=epochs)

    background_tasks.add_task(_run_and_record, "all", _all())
    return {
        "launched":  True,
        "markets":   ["btts", "over_under", "correct_score"],
        "epochs":    epochs,
        "poll_at":   "/api/market-training/status",
    }


@router.post("/train/btts", summary="Train BTTS model (async)")
async def train_btts(
    background_tasks: BackgroundTasks,
    epochs: int = 60,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_admin),
):
    from app.ai.market_trainer import train_btts_model

    async def _go():
        from app.db.database import AsyncSessionLocal
        async with AsyncSessionLocal() as _db:
            return await train_btts_model(_db, epochs=epochs)

    background_tasks.add_task(_run_and_record, "btts", _go())
    return {"launched": True, "market": "btts", "epochs": epochs}


@router.post("/train/ou", summary="Train Over/Under model (async)")
async def train_ou(
    background_tasks: BackgroundTasks,
    epochs: int = 60,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_admin),
):
    from app.ai.market_trainer import train_over_under_model

    async def _go():
        from app.db.database import AsyncSessionLocal
        async with AsyncSessionLocal() as _db:
            return await train_over_under_model(_db, epochs=epochs)

    background_tasks.add_task(_run_and_record, "over_under", _go())
    return {"launched": True, "market": "over_under", "epochs": epochs}


@router.post("/train/cs", summary="Train Correct Score model (async)")
async def train_cs(
    background_tasks: BackgroundTasks,
    epochs: int = 80,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_admin),
):
    from app.ai.market_trainer import train_correct_score_model

    async def _go():
        from app.db.database import AsyncSessionLocal
        async with AsyncSessionLocal() as _db:
            return await train_correct_score_model(_db, epochs=epochs)

    background_tasks.add_task(_run_and_record, "correct_score", _go())
    return {"launched": True, "market": "correct_score", "epochs": epochs}


@router.get("/status", summary="Market model training status + saved models")
async def training_status(
    _: User = Depends(get_current_user),
):
    """Return background job status and list of saved market model files."""
    saved = []
    for key in ["btts_v2", "over_under_v2", "correct_score_v2"]:
        path = os.path.join(_MODELS_DIR, f"{key}.pth")
        if os.path.isfile(path):
            saved.append({
                "model_key":    key,
                "path":         path,
                "size_kb":      round(os.path.getsize(path) / 1024, 1),
                "exists":       True,
            })
        else:
            saved.append({"model_key": key, "exists": False})

    return {
        "jobs":         dict(_job_status),
        "saved_models": saved,
    }


@router.post("/predict/btts", summary="Run BTTS inference on a feature dict")
async def predict_btts(
    features: dict,
    _: User = Depends(get_current_user),
):
    """
    Run the saved BTTS model on a raw feature dict.
    Returns P(no_btts) and P(btts_yes).
    """
    from app.ai.market_models import BTTSModel, build_btts_vector, _BTTS_FEATURE_KEYS
    from app.ai.market_trainer import load_market_model

    model = load_market_model(BTTSModel, BTTSModel.MODEL_KEY, input_size=len(_BTTS_FEATURE_KEYS))
    if model is None:
        return {"error": "BTTS model not yet trained. POST /api/market-training/train/btts first."}

    vec   = build_btts_vector(features)
    proba = model.predict_proba(vec).squeeze().tolist()
    return {
        "model_key":    BTTSModel.MODEL_KEY,
        "btts_no_prob": round(proba[0], 4),
        "btts_yes_prob": round(proba[1], 4),
    }


@router.post("/predict/ou", summary="Run Over/Under inference on a feature dict")
async def predict_ou(
    features: dict,
    n:        float = 2.5,
    _: User = Depends(get_current_user),
):
    """
    Run the saved Over/Under model.
    Returns 5-class goal band distribution + P(over N.5).
    """
    from app.ai.market_models import OverUnderModel, build_ou_vector, _OU_FEATURE_KEYS
    from app.ai.market_trainer import load_market_model

    model = load_market_model(OverUnderModel, OverUnderModel.MODEL_KEY, input_size=len(_OU_FEATURE_KEYS))
    if model is None:
        return {"error": "Over/Under model not yet trained. POST /api/market-training/train/ou first."}

    vec   = build_ou_vector(features)
    proba = model.predict_proba(vec).squeeze().tolist()
    over  = model.over_n5_prob(vec, n)
    return {
        "model_key":    OverUnderModel.MODEL_KEY,
        "goal_bands":   dict(zip(OverUnderModel.CLASS_LABELS, [round(p, 4) for p in proba])),
        f"over_{n}_prob": over,
        f"under_{n}_prob": round(1.0 - over, 4),
    }


@router.post("/predict/cs", summary="Run Correct Score inference on a feature dict")
async def predict_cs(
    features: dict,
    top_n:    int = 5,
    _: User = Depends(get_current_user),
):
    """
    Run the saved Correct Score model.
    Returns top-N most likely exact scores with probabilities.
    """
    from app.ai.market_models import CorrectScoreModel, build_cs_vector, _CS_FEATURE_KEYS
    from app.ai.market_trainer import load_market_model

    model = load_market_model(
        CorrectScoreModel, CorrectScoreModel.MODEL_KEY, input_size=len(_CS_FEATURE_KEYS)
    )
    if model is None:
        return {"error": "Correct Score model not yet trained. POST /api/market-training/train/cs first."}

    vec   = build_cs_vector(features)
    top   = model.top_scores(vec, n=top_n)
    return {
        "model_key":   CorrectScoreModel.MODEL_KEY,
        "top_scores":  top,
    }
