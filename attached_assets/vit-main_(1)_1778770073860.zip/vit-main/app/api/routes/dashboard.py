"""Dashboard summary endpoints — all data properly scoped per user."""

import logging
from decimal import Decimal
from datetime import datetime, timezone, timedelta

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, select, desc, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user, get_optional_user
from app.db.database import get_db
from app.db.models import CLVEntry, Match, Prediction, User

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/dashboard", tags=["Dashboard"])


async def _settled_predictions_for_user(db: AsyncSession, uid: int):
    """
    Return the user's settled predictions joined to their match outcome,
    most-recent first. A prediction is "settled" when:
      - the match has actual_outcome populated, AND
      - the prediction has a bet_side recorded.
    This is the source of truth used by the system-log WIN/LOSS labels;
    accuracy / streak must agree with it.
    """
    rows = await db.execute(
        select(Prediction.bet_side, Match.actual_outcome, Match.kickoff_time)
        .join(Match, Match.id == Prediction.match_id)
        .where(Prediction.user_id == uid)
        .where(Prediction.bet_side.isnot(None))
        .where(Match.actual_outcome.isnot(None))
        .order_by(Match.kickoff_time.desc())
    )
    return rows.all()


def _wins_settled_streak(rows) -> tuple[int, int, int]:
    """Compute (wins, settled, current_win_streak) from prediction/outcome rows."""
    settled = 0
    wins = 0
    streak = 0
    streak_locked = False
    for bet_side, outcome, _ in rows:
        if not bet_side or not outcome:
            continue
        settled += 1
        won = str(bet_side).lower() == str(outcome).lower()
        if won:
            wins += 1
            if not streak_locked:
                streak += 1
        else:
            streak_locked = True
    return wins, settled, streak


@router.get("/summary")
async def get_dashboard_summary(
    current_user=Depends(get_optional_user),
    db: AsyncSession = Depends(get_db),
):
    """Dashboard summary — returns defaults for unauthenticated users."""
    active = (
        await db.execute(
            select(func.count(Match.id)).where(Match.actual_outcome.is_(None))
        )
    ).scalar() or 0

    if current_user is None:
        return {
            "total_predictions": 0,
            "accuracy_rate": 0.0,
            "settled_predictions": 0,
            "wins": 0,
            "roi": 0.0,
            "active_matches": active,
            "wallet_balance": 0.0,
            "streak": 0,
            "authenticated": False,
        }

    uid = current_user.id

    total_predictions = (
        await db.execute(
            select(func.count(Prediction.id)).where(Prediction.user_id == uid)
        )
    ).scalar() or 0

    settled_rows = await _settled_predictions_for_user(db, uid)
    wins, settled, streak = _wins_settled_streak(settled_rows)
    accuracy = round(wins / settled, 4) if settled > 0 else 0.0

    try:
        if hasattr(current_user, "current_streak") and (current_user.current_streak or 0) != streak:
            current_user.current_streak = streak
            await db.commit()
    except Exception:
        await db.rollback()

    u_pred_sub = select(Prediction.id).where(Prediction.user_id == uid).subquery()
    roi_result = (
        await db.execute(
            select(func.sum(CLVEntry.profit))
            .where(CLVEntry.prediction_id.in_(select(u_pred_sub.c.id)))
        )
    ).scalar() or Decimal("0")

    vitcoin_balance = 0.0
    try:
        from app.modules.wallet.models import Wallet
        wallet = (
            await db.execute(select(Wallet).where(Wallet.user_id == uid))
        ).scalar_one_or_none()
        if wallet:
            vitcoin_balance = float(wallet.vitcoin_balance)
    except Exception:
        pass

    return {
        "total_predictions": total_predictions,
        "accuracy_rate": accuracy,
        "settled_predictions": settled,
        "wins": wins,
        "roi": float(roi_result),
        "active_matches": active,
        "wallet_balance": vitcoin_balance,
        "streak": streak,
        "authenticated": True,
    }


@router.get("/vitcoin-price")
async def get_dashboard_vitcoin_price(db: AsyncSession = Depends(get_db)):
    try:
        from app.modules.wallet.pricing import VITCoinPricingEngine
        from app.modules.wallet.models import VITCoinPriceHistory
        engine = VITCoinPricingEngine(db)
        prices = await engine.get_current_price()
        current = float(prices.get("usd", Decimal("0.001")))

        change_24h = 0.0
        try:
            hist_q = await db.execute(
                select(VITCoinPriceHistory)
                .order_by(VITCoinPriceHistory.calculated_at.desc())
                .limit(2)
            )
            history = hist_q.scalars().all()
            if len(history) >= 2:
                prev = float(history[1].price_usd)
                if prev > 0:
                    change_24h = round((current - prev) / prev * 100, 4)
        except Exception:
            pass

        return {"price": current, "change_24h": change_24h}
    except Exception:
        return {"price": 0.001, "change_24h": 0.0}


@router.get("/recent-activity")
async def get_recent_activity(
    limit: int = 10,
    current_user=Depends(get_optional_user),
    db: AsyncSession = Depends(get_db),
):
    if current_user is None:
        return []

    uid = current_user.id
    activity = []

    # 1. Recent predictions
    try:
        pred_rows = await db.execute(
            select(Match, Prediction)
            .join(Prediction, Match.id == Prediction.match_id)
            .where(Prediction.user_id == uid)
            .order_by(Prediction.timestamp.desc())
            .limit(limit)
        )
        for match, pred in pred_rows.all():
            outcome_label = None
            if match.actual_outcome and pred.bet_side:
                outcome_label = (
                    "win" if match.actual_outcome == pred.bet_side else "loss"
                )
            activity.append({
                "id": f"pred-{pred.id}",
                "type": "prediction",
                "icon": "⚽",
                "description": f"{match.home_team} vs {match.away_team}",
                "detail": f"Tipped {(pred.bet_side or '?').upper()}",
                "bet_side": pred.bet_side,
                "outcome": outcome_label,
                "edge": pred.vig_free_edge,
                "created_at": pred.timestamp.isoformat() if pred.timestamp else None,
            })
    except Exception:
        pass

    # 2. Recent task completions
    try:
        from app.modules.tasks.models import UserTaskCompletion, Task as TaskModel
        task_rows = await db.execute(
            select(UserTaskCompletion, TaskModel)
            .join(TaskModel, UserTaskCompletion.task_id == TaskModel.id)
            .where(UserTaskCompletion.user_id == uid)
            .where(UserTaskCompletion.is_completed == True)
            .order_by(UserTaskCompletion.last_completed_at.desc())
            .limit(limit)
        )
        for completion, task in task_rows.all():
            activity.append({
                "id": f"task-{completion.id}",
                "type": "task_completed",
                "icon": "🏆",
                "description": f"Task completed: {task.title}",
                "detail": f"+{task.vit_reward} VIT · +{task.xp_reward} XP",
                "vit_earned": task.vit_reward,
                "xp_earned": task.xp_reward,
                "outcome": "win",
                "created_at": completion.last_completed_at.isoformat()
                if completion.last_completed_at else None,
            })
    except Exception:
        pass

    # 3. Recent wallet transactions (deposits / withdrawals)
    try:
        from app.modules.wallet.models import WalletTransaction
        tx_rows = await db.execute(
            select(WalletTransaction)
            .where(WalletTransaction.user_id == uid)
            .order_by(WalletTransaction.created_at.desc())
            .limit(limit)
        )
        for tx in tx_rows.scalars().all():
            tx_type = getattr(tx, "transaction_type", None)
            direction = getattr(tx, "direction", None)
            amount = float(getattr(tx, "amount", 0) or 0)
            currency = getattr(tx, "currency", "VIT")
            activity.append({
                "id": f"tx-{tx.id}",
                "type": "wallet_transaction",
                "icon": "💰" if (direction and "in" in str(direction).lower()) else "💸",
                "description": f"Wallet {str(tx_type or 'transaction').replace('_', ' ').title()}",
                "detail": f"{amount:,.2f} {currency}",
                "amount": amount,
                "currency": currency,
                "outcome": None,
                "created_at": tx.created_at.isoformat() if tx.created_at else None,
            })
    except Exception:
        pass

    # 4. Login events from audit_log
    try:
        from app.db.models import AuditLog
        login_rows = await db.execute(
            select(AuditLog)
            .where(AuditLog.user_id == uid)
            .where(AuditLog.action.in_(["user.login", "login", "auth.login"]))
            .order_by(AuditLog.created_at.desc())
            .limit(3)
        )
        for log in login_rows.scalars().all():
            activity.append({
                "id": f"login-{log.id}",
                "type": "login",
                "icon": "🔑",
                "description": "Signed in",
                "detail": getattr(log, "ip_address", None) or "—",
                "outcome": None,
                "created_at": log.created_at.isoformat() if log.created_at else None,
            })
    except Exception:
        pass

    # Sort all events newest-first and return the top `limit`
    activity.sort(
        key=lambda e: e.get("created_at") or "1970-01-01T00:00:00",
        reverse=True,
    )
    return activity[:limit]


@router.get("/top-opportunities")
async def get_top_opportunities(
    limit: int = Query(default=5, ge=1, le=20),
    db: AsyncSession = Depends(get_db),
):
    """Return upcoming matches with the highest predicted edge.
    Falls through three levels:
      1. Predictions with vig_free_edge
      2. Any predictions ordered by confidence
      3. Raw upcoming matches with SCIE-derived scores (no prediction required)
    """
    try:
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        lookahead = now + timedelta(days=7)
        lookback = now - timedelta(hours=6)

        # Level 1: predictions with edge data
        result = await db.execute(
            select(Match, Prediction)
            .join(Prediction, Match.id == Prediction.match_id)
            .where(Match.actual_outcome.is_(None))
            .where(Match.kickoff_time >= lookback)
            .where(Match.kickoff_time <= lookahead)
            .where(Prediction.vig_free_edge.isnot(None))
            .order_by(desc(Prediction.vig_free_edge))
            .limit(limit)
        )
        rows = result.all()

        # Level 2: any predictions ordered by confidence
        if not rows:
            result = await db.execute(
                select(Match, Prediction)
                .join(Prediction, Match.id == Prediction.match_id)
                .where(Match.actual_outcome.is_(None))
                .where(Match.kickoff_time >= lookback)
                .where(Match.kickoff_time <= lookahead)
                .order_by(desc(Prediction.confidence))
                .limit(limit)
            )
            rows = result.all()

        if rows:
            opportunities = _build_opportunities(rows, now)
            return {"opportunities": opportunities, "total": len(opportunities)}

        # Level 3: raw upcoming matches → compute SCIE priors on the fly
        match_rows = await db.execute(
            select(Match)
            .where(Match.actual_outcome.is_(None))
            .where(Match.kickoff_time >= lookback)
            .where(Match.kickoff_time <= lookahead)
            .order_by(Match.kickoff_time.asc())
            .limit(limit)
        )
        matches = match_rows.scalars().all()

        if not matches:
            return {"opportunities": [], "total": 0}

        try:
            from app.services.scie import get_match_priors
        except ImportError:
            get_match_priors = None

        opportunities = []
        for match in matches:
            if get_match_priors:
                try:
                    priors = get_match_priors(
                        match.home_team, match.away_team, match.league or "unknown"
                    )
                    hp = float(priors.get("home_prob", 0.42))
                    dp = float(priors.get("draw_prob", 0.26))
                    ap = float(priors.get("away_prob", 0.32))
                except Exception:
                    hp, dp, ap = 0.42, 0.26, 0.32
            else:
                hp, dp, ap = 0.42, 0.26, 0.32

            total = hp + dp + ap
            hp, dp, ap = hp / total, dp / total, ap / total
            conf = max(hp, dp, ap)
            bet_side = "home" if hp >= dp and hp >= ap else ("draw" if dp >= ap else "away")
            edge_pct = round((conf - 0.50) * 100, 1)

            kickoff = match.kickoff_time
            if isinstance(kickoff, datetime):
                if kickoff.date() == now.date():
                    time_label = f"Today {kickoff.strftime('%H:%M')}"
                elif kickoff.date() == (now + timedelta(days=1)).date():
                    time_label = f"Tomorrow {kickoff.strftime('%H:%M')}"
                else:
                    time_label = kickoff.strftime("%b %d %H:%M")
            else:
                time_label = str(kickoff)

            opportunities.append({
                "match": f"{match.home_team} vs {match.away_team}",
                "league": match.league or "Unknown",
                "edge": f"+{edge_pct}%" if edge_pct >= 0 else f"{edge_pct}%",
                "edge_value": edge_pct,
                "ai_confidence": int(round(conf * 100)),
                "time": time_label,
                "bet_side": bet_side,
                "prediction_id": None,
                "match_id": str(match.id),
            })

        opportunities.sort(key=lambda x: x["edge_value"], reverse=True)
        return {"opportunities": opportunities, "total": len(opportunities)}

    except Exception as e:
        logger.warning(f"top-opportunities error: {e}")
        return {"opportunities": [], "total": 0}


def _build_opportunities(rows, now: datetime) -> list:
    opportunities = []
    for match, pred in rows:
        edge_raw = pred.vig_free_edge
        if edge_raw is not None:
            edge_pct = round(float(edge_raw) * 100, 1)
        else:
            conf = float(pred.confidence or 0.60)
            edge_pct = round((conf - 0.50) * 100, 1)

        ai_conf = round(float(pred.confidence or 0.60) * 100, 0)
        kickoff = match.kickoff_time
        if isinstance(kickoff, datetime):
            if kickoff.date() == now.date():
                time_label = f"Today {kickoff.strftime('%H:%M')}"
            elif kickoff.date() == (now + timedelta(days=1)).date():
                time_label = f"Tomorrow {kickoff.strftime('%H:%M')}"
            else:
                time_label = kickoff.strftime("%b %d %H:%M")
        else:
            time_label = str(kickoff)

        opportunities.append({
            "match": f"{match.home_team} vs {match.away_team}",
            "league": match.league or "Unknown",
            "edge": f"+{edge_pct}%" if edge_pct >= 0 else f"{edge_pct}%",
            "edge_value": edge_pct,
            "ai_confidence": int(ai_conf),
            "time": time_label,
            "bet_side": pred.bet_side,
            "prediction_id": str(pred.id),
            "match_id": str(match.id),
        })
    return opportunities


@router.get("/model-confidence")
async def get_model_confidence(db: AsyncSession = Depends(get_db)):
    """Return per-model accuracy/confidence for the dashboard widget.
    Falls through three levels of data sources so it always returns something useful.
    """
    # Level 1: ModelMetadata registry (settled accuracy preferred)
    try:
        from app.modules.ai.models import ModelMetadata
        result = await db.execute(
            select(ModelMetadata)
            .where(ModelMetadata.is_active == True)
            .order_by(ModelMetadata.weight.desc())
        )
        models = result.scalars().all()

        # Type-prior accuracy table sourced from published ML benchmarks for
        # 1X2 football prediction (same source as weight_adjuster._TYPE_PRIORS).
        # Used only when no real settled-accuracy data exists for a model.
        _PRIOR_ACC: dict = {
            "MarketImplied": 70.0, "NeuralEnsemble": 64.0, "LLMConsensus": 63.0,
            "HybridStack": 63.0, "XGBoost": 62.0, "Transformer": 61.0,
            "RandomForest": 60.0, "LSTM": 60.0, "BayesianNet": 59.0,
            "DixonColes": 59.0, "Poisson": 58.0, "Elo": 57.0, "Logistic": 56.0,
        }

        if models:
            model_list = []
            for m in models:
                if m.accuracy is not None:
                    display_accuracy = round(float(m.accuracy) * 100, 1)
                else:
                    display_accuracy = _PRIOR_ACC.get(m.model_type or "", 58.0)

                model_list.append({
                    "name": m.name,
                    "key": m.key,
                    "accuracy": display_accuracy,
                    "weight": round(float(m.weight or 0.05), 3),
                    "predictions": m.predictions_total or 0,
                    "status": "active",
                    "is_trained": m.accuracy is not None,
                })

            total_weight = sum(m["weight"] for m in model_list)
            ensemble_accuracy = (
                sum(m["accuracy"] * m["weight"] for m in model_list)
                / total_weight if total_weight > 0 else 0.0
            )

            return {
                "models": model_list,
                "ensemble_accuracy": round(ensemble_accuracy, 1),
                "active_count": len(model_list),
            }
    except Exception as e:
        logger.debug(f"model-confidence registry error: {e}")

    # Level 2: Most recent AIPredictionAudit
    try:
        from app.modules.ai.models import AIPredictionAudit
        result = await db.execute(
            select(AIPredictionAudit).order_by(AIPredictionAudit.created_at.desc()).limit(1)
        )
        audit = result.scalar_one_or_none()
        if audit and audit.model_outputs:
            models_data = []
            for key, val in audit.model_outputs.items():
                if isinstance(val, dict):
                    conf = val.get("confidence", 0.70)
                    models_data.append({
                        "name": key.replace("_v2", "").replace("_v1", "").replace("_", " ").title(),
                        "key": key,
                        "accuracy": round(float(conf) * 100, 1),
                        "weight": 1.0,
                        "predictions": 0,
                        "status": "active",
                        "is_trained": False,
                    })
            if models_data:
                avg_acc = sum(m["accuracy"] for m in models_data) / len(models_data)
                return {
                    "models": models_data,
                    "ensemble_accuracy": round(avg_acc, 1),
                    "active_count": len(models_data),
                }
    except Exception as e:
        logger.debug(f"model-confidence audit error: {e}")

    # Level 3: Static spec weights — weights updated to match registry.py MODEL_SPECS;
    # accuracy uses type-prior benchmarks, not the synthetic 45+weight*250 formula.
    SPEC_MODELS = [
        ("XGBoost",           "xgb_v2",           0.14, 62.0),
        ("LSTM",              "lstm_v2",           0.11, 60.0),
        ("PoissonGoals",      "poisson_v2",        0.09, 58.0),
        ("HybridStack",       "hybrid_v2",         0.09, 63.0),
        ("Transformer",       "transformer_v2",    0.09, 61.0),
        ("NeuralEnsemble",    "ensemble_v2",       0.08, 64.0),
        ("DixonColes",        "dixon_coles_v2",    0.08, 59.0),
        ("BayesianNet",       "bayes_v2",          0.07, 59.0),
        ("MarketImplied",     "market_v2",         0.10, 70.0),
        ("RandomForest",      "rf_v2",             0.05, 60.0),
        ("LogisticRegression","logistic_v2",       0.06, 56.0),
        ("EloRating",         "elo_v2",            0.04, 57.0),
        ("LLMConsensus",      "llm_consensus_v2",  0.10, 63.0),
    ]
    fallback_models = [
        {
            "name": name,
            "key": key,
            "accuracy": acc,
            "weight": weight,
            "predictions": 0,
            "status": "active",
            "is_trained": False,
        }
        for name, key, weight, acc in SPEC_MODELS
    ]
    total_w = sum(m["weight"] for m in fallback_models)
    ens = sum(m["accuracy"] * m["weight"] for m in fallback_models) / total_w if total_w else 0
    return {
        "models": fallback_models,
        "ensemble_accuracy": round(ens, 1),
        "active_count": len(fallback_models),
    }


@router.get("/leaderboard")
async def get_leaderboard(
    limit: int = Query(default=10, ge=1, le=50),
    db: AsyncSession = Depends(get_db),
):
    """Return top users ranked by prediction performance (XP = predictions*10 + wins*20)."""
    try:
        result = await db.execute(
            select(User).where(User.is_active == True, User.is_banned == False)
        )
        users = result.scalars().all()

        leaderboard = []
        for u in users:
            settled_rows = await _settled_predictions_for_user(db, u.id)
            user_wins, total_settled, streak = _wins_settled_streak(settled_rows)

            total_preds = (await db.execute(
                select(func.count(Prediction.id)).where(Prediction.user_id == u.id)
            )).scalar() or 0

            stored_xp = getattr(u, "total_xp", None) or 0
            xp = stored_xp if stored_xp > 0 else (total_preds * 10 + user_wins * 20)
            win_rate = round(user_wins / total_settled, 4) if total_settled > 0 else 0.0

            tier = u.subscription_tier or "viewer"
            level_map = {"viewer": "Novice", "analyst": "Analyst", "pro": "Pro", "elite": "Elite"}
            level = level_map.get(tier, "Novice")

            leaderboard.append({
                "username": u.username,
                "xp": xp,
                "win_rate": win_rate,
                "level": level,
                "predictions": total_preds,
                "streak": streak,
            })

        leaderboard.sort(key=lambda x: x["xp"], reverse=True)
        leaderboard = leaderboard[:limit]
        for i, entry in enumerate(leaderboard):
            entry["rank"] = i + 1

        return {"leaderboard": leaderboard, "total": len(leaderboard)}
    except Exception as e:
        logger.warning(f"leaderboard error: {e}")
        return {"leaderboard": [], "total": 0}


@router.get("/achievements")
async def get_achievements(
    current_user=Depends(get_optional_user),
    db: AsyncSession = Depends(get_db),
):
    """Return achievement status — returns locked defaults for unauthenticated users."""
    default_achievements = [
        {"id": "first", "name": "First Blood", "description": "Make your first prediction",
         "icon": "🎯", "earned": False, "rarity": "common"},
        {"id": "accuracy70", "name": "Sharpshooter", "description": "Reach 70% win rate (min 10 settled)",
         "icon": "🎖️", "earned": False, "rarity": "rare"},
        {"id": "streak5", "name": "On Fire", "description": "Win 5 predictions in a row",
         "icon": "🔥", "earned": False, "rarity": "rare"},
        {"id": "prediction50", "name": "Volume Player", "description": "Make 50 predictions",
         "icon": "📊", "earned": False, "rarity": "common"},
        {"id": "vitcoin1k", "name": "VIT Whale", "description": "Accumulate 1,000 VITCoin",
         "icon": "🐋", "earned": False, "rarity": "epic"},
        {"id": "validator", "name": "Network Defender", "description": "Become a validator",
         "icon": "🛡️", "earned": False, "rarity": "legendary"},
    ]

    if current_user is None:
        return {"achievements": default_achievements}

    try:
        uid = current_user.id

        total_all_preds = (await db.execute(
            select(func.count(Prediction.id)).where(Prediction.user_id == uid)
        )).scalar() or 0

        settled_rows = await _settled_predictions_for_user(db, uid)
        total_wins, total_settled, _ = _wins_settled_streak(settled_rows)
        win_rate = total_wins / total_settled if total_settled > 0 else 0.0

        vitcoin_balance = 0.0
        try:
            from app.modules.wallet.models import Wallet
            wallet = (await db.execute(
                select(Wallet).where(Wallet.user_id == uid)
            )).scalar_one_or_none()
            if wallet:
                vitcoin_balance = float(wallet.vitcoin_balance)
        except Exception:
            pass

        is_validator = current_user.role == "validator"
        streak = getattr(current_user, "current_streak", 0) or 0

        achievements = [
            {"id": "first", "name": "First Blood", "description": "Make your first prediction",
             "icon": "🎯", "earned": total_all_preds >= 1, "rarity": "common"},
            {"id": "accuracy70", "name": "Sharpshooter", "description": "Reach 70% win rate (min 10 settled)",
             "icon": "🎖️", "earned": total_settled >= 10 and win_rate >= 0.70, "rarity": "rare"},
            {"id": "streak5", "name": "On Fire", "description": "Win 5 predictions in a row",
             "icon": "🔥", "earned": streak >= 5, "rarity": "rare"},
            {"id": "prediction50", "name": "Volume Player", "description": "Make 50 predictions",
             "icon": "📊", "earned": total_all_preds >= 50, "rarity": "common"},
            {"id": "vitcoin1k", "name": "VIT Whale", "description": "Accumulate 1,000 VITCoin",
             "icon": "🐋", "earned": vitcoin_balance >= 1000, "rarity": "epic"},
            {"id": "validator", "name": "Network Defender", "description": "Become a validator",
             "icon": "🛡️", "earned": is_validator, "rarity": "legendary"},
        ]
        return {"achievements": achievements}
    except Exception as e:
        logger.warning(f"achievements error: {e}")
        return {"achievements": default_achievements}
