# app/api/routes/predict.py
# VIT Sports Intelligence Network — v2.1.0
# Fix: Full prediction data passed to BetAlert (models_used, all probs, all odds)
# Fix: Alert sent on ANY prediction (not just >3% edge) so Telegram shows status
# Fix: Models count and data source included in response

import hashlib
import json
import logging
import math
import os
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from datetime import datetime, timezone

from app.config import APP_VERSION, MAX_STAKE, MIN_EDGE_THRESHOLD, MAX_PREDICTIONS_PER_DAY
from app.db.database import get_db
from app.db.models import Match, Prediction
from app.schemas.schemas import MatchRequest, PredictionResponse
from app.services.clv_tracker import CLVTracker
from app.services.market_utils import MarketUtils
from app.api.middleware.auth import verify_api_key
from app.api.deps import get_optional_user
from app.services.alerts import BetAlert
from app.core.dependencies import get_orchestrator_dep, get_telegram_dep

from app.tasks.clv import update_clv_task
from app.tasks.edges import recalculate_edges_task
from app.services.decision_logger import DecisionLogger
from app.services.predict_features import build_predict_features

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/predict",
    tags=["predictions"],
    dependencies=[Depends(verify_api_key)]
)

VERSION = APP_VERSION


def to_naive_utc(dt_input) -> datetime:
    if isinstance(dt_input, str):
        try:
            parsed = datetime.fromisoformat(dt_input.replace("Z", "+00:00"))
            return parsed.replace(tzinfo=None)
        except Exception as e:
            logger.warning(f"Failed to parse kickoff_time '{dt_input}': {e}")
            return datetime.now(timezone.utc).replace(tzinfo=None)
    elif isinstance(dt_input, datetime):
        if dt_input.tzinfo is not None:
            return dt_input.astimezone(timezone.utc).replace(tzinfo=None)
        return dt_input
    return datetime.now(timezone.utc).replace(tzinfo=None)


def create_idempotency_key(match: MatchRequest, user_id: Optional[int] = None) -> str:
    # Include rounded odds so market movement triggers a fresh prediction.
    # Include user_id so different users never share a cached prediction record.
    odds = match.market_odds or {}
    odds_sig = {k: round(float(v), 2) for k, v in odds.items() if v}
    content = {
        "home_team":    match.home_team,
        "away_team":    match.away_team,
        "kickoff_time": match.kickoff_time.isoformat(),
        "league":       match.league,
        "odds_sig":     odds_sig,
        "user_id":      user_id,
    }
    return hashlib.sha256(json.dumps(content, sort_keys=True).encode()).hexdigest()[:32]


def _argmax_side(hp: float, dp: float, ap: float) -> str:
    """Return 'home' / 'draw' / 'away' for the highest of the three probs."""
    return max((("home", hp), ("draw", dp), ("away", ap)), key=lambda x: x[1])[0]


def compute_model_consensus(
    insights: list,
    final_pick: Optional[str] = None,
    total_specs: Optional[int] = None,
) -> dict:
    """
    Build a per-model consensus block from the orchestrator's individual results.

    Each model is asked to vote with its own argmax of (home/draw/away). Failed
    models and models with all-zero probs are excluded from voting. We report
    the agreed side, the agreement %, the per-side vote distribution, and the
    average winning-side probability across the agreeing models — useful for
    "10/13 models agree on HOME at 61% avg" style UI copy.
    """
    voted = []
    for p in insights or []:
        if p.get("failed"):
            continue
        try:
            hp = float(p.get("home_prob") or 0.0)
            dp = float(p.get("draw_prob") or 0.0)
            ap = float(p.get("away_prob") or 0.0)
        except (TypeError, ValueError):
            continue
        if hp + dp + ap <= 0:
            continue
        voted.append({
            "model_name": p.get("model_name") or "unknown",
            "side":       _argmax_side(hp, dp, ap),
            "probs":      {"home": hp, "draw": dp, "away": ap},
        })

    distribution = {"home": 0, "draw": 0, "away": 0}
    for v in voted:
        distribution[v["side"]] = distribution.get(v["side"], 0) + 1

    if not voted:
        return {
            "agreed_side":         None,
            "agreement_pct":       0.0,
            "total_models":        int(total_specs or 0),
            "voted_models":        0,
            "side_distribution":   distribution,
            "top_pick_avg_prob":   0.0,
            "matches_final_pick":  False,
            "model_picks": [],
        }

    agreed_side, agreed_count = max(distribution.items(), key=lambda kv: kv[1])
    agreement_pct = agreed_count / len(voted)
    avg_winning_prob = (
        sum(v["probs"][agreed_side] for v in voted if v["side"] == agreed_side)
        / max(agreed_count, 1)
    )
    matches_final = (
        final_pick is not None
        and agreed_side in {"home", "draw", "away"}
        and final_pick == agreed_side
    )

    return {
        "agreed_side":        agreed_side,
        "agreement_pct":      round(agreement_pct, 4),
        "total_models":       int(total_specs or len(voted)),
        "voted_models":       len(voted),
        "side_distribution":  distribution,
        "top_pick_avg_prob":  round(avg_winning_prob, 4),
        "matches_final_pick": matches_final,
        "model_picks": [
            {"model_name": v["model_name"], "side": v["side"],
             "prob": round(v["probs"][v["side"]], 4)}
            for v in voted
        ],
    }


def build_alternative_bets(
    best_bet: dict,
    *,
    top_n: int = 5,
    min_edge: float = 0.0,
    max_kelly: float = 0.10,
) -> list:
    """
    Pull the top-N alternative bets from the multi-market candidate ladder
    that determine_best_bet already produced.

    Sorted by true_edge desc, with the chosen best bet excluded. Each entry
    carries enough info to render directly: market, side, model_prob, vig-free
    fair price, edge, raw edge, decimal odds, and a Kelly-clamped suggested
    stake fraction so the UI can offer "stake at 1/2 Kelly" toggles.
    """
    candidates = best_bet.get("candidates") or []
    chosen_key = (best_bet.get("best_market"), best_bet.get("best_side"))

    pool = [
        c for c in candidates
        if (c.get("market"), c.get("side")) != chosen_key
        and float(c.get("true_edge") or 0) >= min_edge
        and float(c.get("odds") or 0) > 1
    ]
    pool.sort(key=lambda c: float(c.get("true_edge") or 0), reverse=True)

    out: list = []
    for c in pool[:max(0, top_n)]:
        odds = float(c.get("odds") or 0)
        prob = float(c.get("model_prob") or 0)
        b = max(odds - 1, 1e-6)
        kelly = (b * prob - (1 - prob)) / b
        kelly = max(0.0, min(kelly, max_kelly))
        out.append({
            "market":        c.get("market"),
            "side":          c.get("side"),
            "model_prob":    round(prob, 4),
            "vig_free_prob": round(float(c.get("vig_free_prob") or 0), 4),
            "edge":          round(float(c.get("true_edge") or 0), 4),
            "raw_edge":      round(float(c.get("raw_edge") or 0), 4),
            "odds":          round(odds, 3),
            "kelly_stake":   round(kelly, 4),
        })
    return out


def compute_vit_score(
    edge: float,
    agreement_pct: float,
    confidence: float,
    *,
    home_prob: float = 0.0,
    draw_prob: float = 0.0,
    away_prob: float = 0.0,
    models_voted: int = 0,
    total_models: int = 13,
    prediction_age_hours: float = 0.0,
) -> dict:
    """
    Compute the VIT (Value Intelligence Trust) composite score — v3.

    Four pillars  (weights: V=35 % · I=30 % · T=25 % · R=10 %):

    V — Value (35 %)
        Primary  : vig-free edge × 500  (20 % edge → V=100)
        Fallback : when no odds data, probability margin above uniform × 300
                   (max_prob − 1/3) · 300, capped at 60 so no-odds picks
                   can reach at most SOLID without confirmed market edge.

    I — Intelligence (30 %)
        Argmax-consensus: fraction of the 13-model ensemble that votes the
        same winning side as the final ensemble prediction (not ±5 % threshold).
        Depth-adjusted by voting coverage ratio, floored at 0.70.

    T — Trust (25 %)
        Shannon-entropy sharpness from the 1×2 probability distribution.
        Uniform (1/3,1/3,1/3) → T≈50; sharp (0.85,0.10,0.05) → T≈90.
        Falls back to raw confidence × 100 when probs are unavailable.

    R — Recency (10 %)
        Fresh predictions (age < 2 h) score R=100.
        Decays linearly: R = max(0, 100 − age_hours × 2.083).
        At 48 h the prediction is fully stale and R = 0.

    Quality multiplier: 0.85 when no market odds are present (edge=0),
    so no-odds predictions are honestly discounted across the board.

    Score range  : 0–100
    Tiers        : ELITE ≥72 · STRONG ≥55 · SOLID ≥40 · WATCHLIST ≥25 · SKIP <25
    """
    edge = float(edge or 0)

    # ── Value pillar (35 %) ───────────────────────────────────────────────────
    has_odds = edge > 0.0
    if has_odds:
        v = min(100.0, edge * 500.0)
    else:
        max_p = max(float(home_prob or 0), float(draw_prob or 0), float(away_prob or 0))
        margin = max(0.0, max_p - (1.0 / 3.0))
        v = min(60.0, margin * 300.0)

    # ── Intelligence pillar (30 %) ────────────────────────────────────────────
    i_base = min(100.0, max(0.0, float(agreement_pct or 0) * 100.0))
    voted_ratio = (models_voted / max(total_models, 1)) if models_voted > 0 else 1.0
    depth_adj = min(1.0, 0.70 + 0.30 * voted_ratio)
    i = i_base * depth_adj

    # ── Trust pillar (25 %) ───────────────────────────────────────────────────
    hp = float(home_prob or 0)
    dp = float(draw_prob or 0)
    ap = float(away_prob or 0)
    prob_list = [p for p in (hp, dp, ap) if p > 1e-9]
    if len(prob_list) >= 2:
        ent = -sum(p * math.log(p) for p in prob_list)
        max_ent = math.log(3)
        normalised = max(0.0, 1.0 - ent / max_ent)
        t = min(95.0, 50.0 + normalised * 50.0)
    else:
        t = min(95.0, max(0.0, float(confidence or 0) * 100.0))

    # ── Recency pillar (10 %) ─────────────────────────────────────────────────
    # 100 at 0 h → 0 at 48 h  (2.083 pts per hour)
    r = max(0.0, min(100.0, 100.0 - float(prediction_age_hours or 0) * 2.083))

    # ── Composite score ───────────────────────────────────────────────────────
    quality = 1.0 if has_odds else 0.85
    raw = 0.35 * v + 0.30 * i + 0.25 * t + 0.10 * r
    score = round(min(100.0, max(0.0, quality * raw)), 1)

    if score >= 72:   tier = "ELITE"
    elif score >= 55: tier = "STRONG"
    elif score >= 40: tier = "SOLID"
    elif score >= 25: tier = "WATCHLIST"
    else:             tier = "SKIP"

    return {
        "vit_score":      score,
        "vit_tier":       tier,
        "vit_components": {
            "value":        round(v, 1),
            "intelligence": round(i, 1),
            "trust":        round(t, 1),
            "recency":      round(r, 1),
        },
        "has_market_odds": has_odds,
    }


def _entropy_confidence(hp: float, dp: float, ap: float) -> float:
    """
    Map a 1x2 probability distribution to a confidence score in [0.50, 0.95].

    v2: power-law (sqrt) amplification mirrors the updated ModelOrchestrator
    formula so the vig-removal fallback path is consistent.

    Uniform (1/3, 1/3, 1/3) → ~0.50.
    Sharp consensus (0.85, 0.10, 0.05) → ~0.87.
    """
    probs = [p for p in (hp, dp, ap) if p > 0]
    if not probs:
        return 0.50
    import math as _math
    ent = -sum(p * _math.log(p) for p in probs)
    max_ent = _math.log(3)
    normalised = max(0.0, min(1.0, 1.0 - (ent / max_ent)))
    amplified = _math.sqrt(normalised + 1e-9)
    return round(min(0.95, 0.50 + amplified * 0.45), 3)


def validate_prediction_response(result: dict, market_odds: Optional[dict] = None) -> dict:
    """
    Validate orchestrator response — normalise probabilities, fail fast on missing fields.

    Fallback policy (per VIT spec §1.4):
    NEVER return 33/33/33 uniform distribution.
    If the ensemble returns zero-sum, apply vig-removed market probabilities instead.
    """
    required = ["home_prob", "draw_prob", "away_prob"]
    for field in required:
        if field not in result:
            raise ValueError(f"Orchestrator response missing: {field}")

    hp = float(result["home_prob"])
    dp = float(result["draw_prob"])
    ap = float(result["away_prob"])
    total = hp + dp + ap

    if total <= 0:
        # Spec §1.4: use vig-removed market odds — never 33/33/33
        logger.warning("Orchestrator returned zero-sum probabilities — applying market vig-removal fallback")
        odds = market_odds or {}
        ho = MarketUtils.validate_odds(odds.get("home"))
        do_ = MarketUtils.validate_odds(odds.get("draw"))
        ao = MarketUtils.validate_odds(odds.get("away"))
        if ho and do_ and ao:
            implied = {"home": 1 / ho, "draw": 1 / do_, "away": 1 / ao}
            vig_total = sum(implied.values())
            result["home_prob"] = implied["home"] / vig_total
            result["draw_prob"] = implied["draw"] / vig_total
            result["away_prob"] = implied["away"] / vig_total
            result["fallback_used"] = True
            # Derive confidence from the actual spread of vig-removed market
            # probabilities (entropy-based) rather than a constant. Uniform
            # ~0.50, sharp consensus ~0.95 — matches ModelOrchestrator's
            # entropy→confidence mapping so downstream logic stays consistent.
            result["confidence"] = _entropy_confidence(
                result["home_prob"], result["draw_prob"], result["away_prob"]
            )
            logger.info(
                "Fallback probs from vig-removal: H=%.3f D=%.3f A=%.3f conf=%.3f",
                result["home_prob"], result["draw_prob"], result["away_prob"],
                result["confidence"],
            )
        else:
            # No odds at all — raise so the caller can surface the error clearly
            raise ValueError(
                "Orchestrator produced zero-sum probabilities and no valid market odds "
                "were supplied — cannot generate a prediction for this fixture."
            )
    else:
        # Always normalise — ensemble models can drift; 10% tolerance before hard error
        if abs(total - 1.0) > 0.10:
            raise ValueError(f"Probabilities sum to {total:.4f} (>10% off) — likely model failure")
        result["home_prob"] = hp / total
        result["draw_prob"] = dp / total
        result["away_prob"] = ap / total

    return result


def build_prediction_response(
    prediction: Prediction,
    match: Match,
    orchestrator: Optional[object] = None,
    data_quality: Optional[dict] = None,
    data_source: str = "neural_ensemble",
) -> PredictionResponse:
    # Calculate intelligence metrics
    models_used = len(prediction.model_insights) if prediction.model_insights else 0
    neural_consensus_score = prediction.consensus_prob * 100  # Convert to percentage
    
    # Intelligence rating based on confidence and edge
    if prediction.confidence > 0.8 and prediction.vig_free_edge > 0.05:
        intelligence_rating = "EXCELLENT"
    elif prediction.confidence > 0.7 and prediction.vig_free_edge > 0.03:
        intelligence_rating = "VERY GOOD"
    elif prediction.confidence > 0.6 and prediction.vig_free_edge > 0.02:
        intelligence_rating = "GOOD"
    elif prediction.confidence > 0.5:
        intelligence_rating = "FAIR"
    else:
        intelligence_rating = "POOR"
    
    # Estimate prediction accuracy based on historical patterns
    prediction_accuracy_estimate = min(85.0, prediction.confidence * 100 + prediction.vig_free_edge * 200)

    # VIT composite score — v2 (entropy Trust + prob-margin Value fallback)
    _mc = prediction.model_consensus or {}
    _agreement = float(_mc.get("agreement_pct", 0.0))
    _models_voted = int(_mc.get("voted_models", 0))
    _total_models = int(_mc.get("total_models", 13))
    _vit = compute_vit_score(
        prediction.vig_free_edge or 0,
        _agreement,
        prediction.confidence or 0,
        home_prob=float(prediction.home_prob or 0),
        draw_prob=float(prediction.draw_prob or 0),
        away_prob=float(prediction.away_prob or 0),
        models_voted=_models_voted,
        total_models=_total_models,
    )

    return PredictionResponse(
        match_id=prediction.match_id,
        home_prob=prediction.home_prob,
        draw_prob=prediction.draw_prob,
        away_prob=prediction.away_prob,
        over_25_prob=prediction.over_25_prob,
        under_25_prob=prediction.under_25_prob,
        btts_prob=prediction.btts_prob,
        # v4.6.1 — AH + CS
        ah_line=prediction.ah_line,
        ah_home_prob=prediction.ah_home_prob,
        ah_away_prob=prediction.ah_away_prob,
        ah_lines=prediction.ah_lines,
        cs_probs=prediction.cs_probs,
        top_correct_score=prediction.top_correct_score,
        top_cs_prob=prediction.top_cs_prob,
        # v4.6.2 — consensus + alternatives
        model_consensus=prediction.model_consensus,
        alternative_bets=prediction.alternative_bets,
        consensus_prob=prediction.consensus_prob,
        final_ev=prediction.final_ev,
        recommended_stake=prediction.recommended_stake,
        edge=prediction.vig_free_edge,
        confidence=prediction.confidence,
        timestamp=prediction.timestamp,
        
        # Enhanced Intelligence Data
        models_used=models_used,
        models_total=getattr(orchestrator, '_total_model_specs', models_used) if orchestrator else models_used,
        data_source=data_source,  # Real source from orchestrator (e.g. "differentiated_ensemble_v3")
        bet_side=prediction.bet_side,
        entry_odds=prediction.entry_odds,
        raw_edge=prediction.raw_edge,
        normalized_edge=prediction.normalized_edge,
        vig_free_edge=prediction.vig_free_edge,
        model_weights=prediction.model_weights or {},
        model_insights=prediction.model_insights or [],
        neural_consensus_score=neural_consensus_score,
        intelligence_rating=intelligence_rating,
        prediction_accuracy_estimate=prediction_accuracy_estimate,
        data_quality=data_quality,
        vit_score=_vit["vit_score"],
        vit_tier=_vit["vit_tier"],
        vit_components=_vit["vit_components"],
    )


@router.post("", response_model=PredictionResponse)
async def predict(
    match: MatchRequest,
    db: AsyncSession = Depends(get_db),
    orchestrator = Depends(get_orchestrator_dep),
    telegram_alerts = Depends(get_telegram_dep),
    current_user = Depends(get_optional_user),
):
    """
    Generate prediction for a match.

    v2.1.0:
    - Passes full market odds to orchestrator
    - Sends Telegram alert for ALL predictions (edge or no edge)
      so the channel always shows match status
    - BetAlert includes model count, all probs, all odds, data source
    
    v2.4.0:
    - Accepts fixture_id to track which specific fixture was predicted
    - Logs fixture_id for debugging and fixture-prediction mapping
    """
    if orchestrator is None:
        raise HTTPException(status_code=503, detail="Orchestrator not initialized")

    fixture_id = match.fixture_id if match.fixture_id else "unknown"
    user_id: Optional[int] = current_user.id if current_user else None

    # C-1 — per-user daily prediction rate limit
    if user_id is not None:
        from app.core.rate_limit import check_prediction_limit
        from datetime import date as _rl_date, timedelta as _rl_td
        allowed, current_count, resets_at = check_prediction_limit(user_id, MAX_PREDICTIONS_PER_DAY)
        if not allowed:
            raise HTTPException(
                status_code=429,
                detail={
                    "error": "Daily prediction limit reached",
                    "limit": MAX_PREDICTIONS_PER_DAY,
                    "used": current_count,
                    "resets_at": resets_at,
                },
            )
    idempotency_key = create_idempotency_key(match, user_id)
    naive_kickoff = to_naive_utc(match.kickoff_time)

    # v4.10.0 — fallback / data-quality tracker.
    # Every degraded code path appends a flag here so the response (and the
    # frontend) can clearly distinguish a real-data prediction from one that
    # leaned on synthetic odds, neutral features, or a vig-removal fallback.
    data_quality: dict = {
        "market_odds_fallback":   False,
        "feature_completeness":   None,    # 0..1 from predict_features
        "vig_removal_fallback":   False,
        "pkl_models_loaded":      0,
        "failed_models":          [],
        "warnings":               [],
        "calibration": {                   # Phase C
            "method":              None,
            "calibrated_models":   0,
            "uncalibrated_models": [],
            "partial_models":      [],
        },
    }

    try:
        if not MarketUtils.validate_odds_dict(match.market_odds):
            logger.warning(
                "PREDICT_FALLBACK market_odds invalid for %s vs %s — using "
                "league-average fallback odds for league=%s",
                match.home_team, match.away_team, match.league,
            )
            match.market_odds = MarketUtils.get_fallback_odds(match.league)
            data_quality["market_odds_fallback"] = True
            data_quality["warnings"].append("market_odds_fallback")

        # --- Idempotency: return existing prediction if same hash ---
        existing = await db.execute(
            select(Prediction).where(Prediction.request_hash == idempotency_key)
        )
        existing_pred = existing.scalar_one_or_none()
        if existing_pred:
            # Return cached prediction instead of 409
            existing_match_res = await db.execute(
                select(Match).where(Match.id == existing_pred.match_id)
            )
            ex_match = existing_match_res.scalar_one_or_none()
            if ex_match:
                logger.info(f"Returning cached prediction for hash={idempotency_key}")
                cached_dq = dict(data_quality)
                cached_dq["warnings"].append("served_from_cache")
                return build_prediction_response(existing_pred, ex_match, orchestrator, cached_dq)

        # --- Find or create match ---
        # 1. Try by external_id (fixture_id)
        db_match = None
        if match.fixture_id and match.fixture_id != "unknown":
            ext_res = await db.execute(
                select(Match).where(Match.external_id == str(match.fixture_id))
            )
            db_match = ext_res.scalar_one_or_none()

        # 2. Try by cross-source fingerprint (date::home::away::league)
        if db_match is None:
            try:
                from app.data.match_dedup import find_existing_match
                # Use a savepoint so that if find_existing_match raises a DB
                # exception (e.g. missing column) it rolls back only to the
                # savepoint and does NOT abort the outer transaction.  This is
                # critical for PostgreSQL where any uncaught exception inside a
                # transaction leaves the whole transaction in a failed state.
                async with db.begin_nested():
                    db_match = await find_existing_match(db, match.home_team, match.away_team, naive_kickoff, match.league)
            except Exception:
                pass

        # 3. Fallback: fuzzy teams + 24-hour kickoff window (no league constraint to avoid
        #    false misses when league names differ between source and DB)
        if db_match is None:
            from datetime import timedelta
            window_start = naive_kickoff - timedelta(hours=24)
            window_end   = naive_kickoff + timedelta(hours=24)
            existing_match_res = await db.execute(
                select(Match).where(
                    Match.home_team == match.home_team,
                    Match.away_team == match.away_team,
                    Match.kickoff_time >= window_start,
                    Match.kickoff_time <= window_end,
                )
            )
            db_match = existing_match_res.scalars().first()

        if db_match is None:
            # Create new match record — stamp fingerprint so future dedup works
            try:
                from app.data.match_dedup import compute_fingerprint as _cfp
                _fp = _cfp(match.home_team, match.away_team, naive_kickoff, match.league)
            except Exception:
                _fp = None
            db_match = Match(
                home_team=match.home_team,
                away_team=match.away_team,
                league=match.league,
                kickoff_time=naive_kickoff,
                source="predict",
                fingerprint=_fp,
                opening_odds_home=match.market_odds.get("home"),
                opening_odds_draw=match.market_odds.get("draw"),
                opening_odds_away=match.market_odds.get("away"),
            )
            db.add(db_match)
            await db.flush()
            logger.info(f"Match created: {match.home_team} vs {match.away_team} @ {naive_kickoff}")
        else:
            logger.info(f"Reusing existing match id={db_match.id}: {match.home_team} vs {match.away_team}")

        # --- Run orchestrator with full market odds AND real per-team features ---
        # v4.10.0 (Phase A): replace hardcoded sklearn feature globals with
        # rolling form / H2H / ELO-proxy values queried from the DB.
        try:
            # Run build_predict_features in its own isolated session so that
            # any internal DB exception (e.g. missing team_elo table) that is
            # caught inside the function does NOT abort our outer transaction.
            # Using the same session would leave the PostgreSQL connection in
            # "InFailedSQLTransactionError" state even if Python never sees the
            # exception, breaking the subsequent Prediction INSERT.
            from app.db.database import AsyncSessionLocal
            async with AsyncSessionLocal() as _feat_db:
                match_features = await build_predict_features(
                    _feat_db, match.home_team, match.away_team, match.league
                )
        except Exception as exc:
            logger.warning(
                "PREDICT_FALLBACK build_predict_features raised %s — using "
                "neutral feature defaults",
                exc,
            )
            match_features = {}
            data_quality["warnings"].append("feature_builder_exception")

        completeness = float(match_features.get("feature_completeness", 0.0)) if match_features else 0.0
        data_quality["feature_completeness"] = round(completeness, 3)
        if completeness < 0.3:
            logger.warning(
                "PREDICT_FALLBACK low feature completeness=%.2f for %s vs %s — "
                "models will lean heavily on neutral defaults",
                completeness, match.home_team, match.away_team,
            )
            data_quality["warnings"].append("low_feature_completeness")

        features = {
            "home_team":      match.home_team,
            "away_team":      match.away_team,
            "league":         match.league,
            "market_odds":    match.market_odds,     # ← v2.1.0: always passes real odds
            "match_features": match_features,         # ← v4.10.0: real rolling features
        }

        raw_result = await orchestrator.predict(features, idempotency_key)
        pred_data  = raw_result.get("predictions", raw_result)
        result     = validate_prediction_response(pred_data, market_odds=match.market_odds)

        # Vig-removal fallback was triggered inside validate_prediction_response
        if result.get("fallback_used"):
            logger.warning(
                "PREDICT_FALLBACK ensemble returned zero-sum probabilities for "
                "%s vs %s — used vig-removed market odds as final probabilities",
                match.home_team, match.away_team,
            )
            data_quality["vig_removal_fallback"] = True
            data_quality["warnings"].append("vig_removal_fallback")

        # --- Extract all probabilities ---
        home_prob = float(result.get("home_prob", 0.0))
        draw_prob = float(result.get("draw_prob", 0.0))
        away_prob = float(result.get("away_prob", 0.0))

        # --- Extract market odds (with league-aware fallbacks) ---
        fallback = MarketUtils.get_fallback_odds(match.league)
        home_odds = float(match.market_odds.get("home") or fallback.get("home", 2.30))
        draw_odds = float(match.market_odds.get("draw") or fallback.get("draw", 3.30))
        away_odds = float(match.market_odds.get("away") or fallback.get("away", 3.10))

        # --- Best bet calculation (v4.6.1: multi-market — 1X2 + O/U 2.5 + BTTS) ---
        _o25 = result.get("over_25_prob") or result.get("over_2_5_prob")
        _u25 = result.get("under_25_prob") or result.get("under_2_5_prob")
        _btts = result.get("btts_prob")
        _no_btts = result.get("no_btts_prob")
        _mo = match.market_odds or {}
        best_bet = MarketUtils.determine_best_bet(
            home_prob, draw_prob, away_prob,
            home_odds, draw_odds, away_odds,
            over_25_prob=_o25,
            under_25_prob=_u25,
            over_25_odds=_mo.get("over_2_5") or _mo.get("over_25"),
            under_25_odds=_mo.get("under_2_5") or _mo.get("under_25"),
            btts_prob=_btts,
            no_btts_prob=_no_btts,
            btts_yes_odds=_mo.get("btts_yes") or _mo.get("btts"),
            btts_no_odds=_mo.get("btts_no"),
            # v4.6.1 — Asian Handicap (only scored if bookmaker prices are present)
            ah_line=result.get("ah_line"),
            ah_home_prob=result.get("ah_home_prob"),
            ah_away_prob=result.get("ah_away_prob"),
            ah_home_odds=_mo.get("ah_home"),
            ah_away_odds=_mo.get("ah_away"),
            # v4.6.1 — Correct Score (bookmaker priced ladder)
            cs_probs=result.get("cs_probs"),
            cs_odds=_mo.get("cs_odds") if isinstance(_mo.get("cs_odds"), dict) else None,
        )

        recommended_stake = min(best_bet.get("kelly_stake", 0), MAX_STAKE)

        probs         = {"home": home_prob, "draw": draw_prob, "away": away_prob}
        # consensus_prob should reflect the model's probability for the chosen
        # bet side, not simply the 1x2 maximum.  When the best bet is on a
        # non-1x2 market (e.g. over_2_5, btts_yes) we use that model_prob;
        # for 1x2 bets we read the matching probability directly.
        _chosen_side   = best_bet.get("best_side")
        _chosen_market = best_bet.get("best_market")
        if _chosen_market == "1x2" and _chosen_side in probs:
            consensus_prob = probs[_chosen_side]
        elif best_bet.get("model_prob") is not None:
            consensus_prob = float(best_bet["model_prob"])
        else:
            consensus_prob = max(probs.values())

        # --- v2.1.0: Extract model metadata from orchestrator result ---
        models_used   = result.get("models_used", raw_result.get("models_count", 0))
        models_total  = result.get("models_total", orchestrator._total_model_specs if orchestrator else 0)
        data_source   = result.get("data_source", "market_implied")
        # Confidence: prefer the orchestrator's reported value; otherwise derive
        # from the actual probability distribution. Never fall back to a fixed
        # constant — that would be presenting a hardcoded number as a model
        # confidence to the user.
        raw_conf = result.get("confidence")
        if isinstance(raw_conf, dict) and raw_conf.get("1x2") is not None:
            confidence_val = float(raw_conf["1x2"])
        elif isinstance(raw_conf, (int, float)):
            confidence_val = float(raw_conf)
        else:
            confidence_val = _entropy_confidence(home_prob, draw_prob, away_prob)

        # --- Build model insights for storage ---
        individual_results    = raw_result.get("individual_results", [])
        model_insights_payload = []
        for p in individual_results:
            raw_conf = p.get("confidence", {})
            if isinstance(raw_conf, dict):
                scalar_conf = raw_conf.get("1x2", 0.0)
                conf_breakdown = raw_conf
            else:
                scalar_conf = float(raw_conf or 0.0)
                conf_breakdown = {}
            model_insights_payload.append({
                "model_name":            p.get("model_name"),
                "model_type":            p.get("model_type"),
                "model_weight":          p.get("model_weight", 1.0),
                "supported_markets":     p.get("supported_markets", []),
                "home_prob":             p.get("home_prob"),
                "draw_prob":             p.get("draw_prob"),
                "away_prob":             p.get("away_prob"),
                "over_2_5_prob":         p.get("over_2_5_prob"),
                "btts_prob":             p.get("btts_prob"),
                "home_goals_expectation": p.get("home_goals_expectation"),
                "away_goals_expectation": p.get("away_goals_expectation"),
                "confidence":            scalar_conf,
                "confidence_breakdown":  conf_breakdown,
                "latency_ms":            p.get("latency_ms"),
                "failed":                p.get("failed", False),
                "error":                 p.get("error"),
                "calibration":           p.get("calibration"),
            })

            # Track per-model fallback signals for the data_quality block.
            if p.get("failed"):
                data_quality["failed_models"].append(p.get("model_name") or "unknown")
            # Trained-pkl source: orchestrator marks it via "source": "trained"
            # on per-model meta when the .pkl was loaded. Best-effort count.
            if p.get("source") == "trained" or p.get("pkl_loaded") is True:
                data_quality["pkl_models_loaded"] += 1

            # Phase C — calibration meta (set by model_orchestrator)
            cal = p.get("calibration") or {}
            mname = p.get("model_name") or "unknown"
            if cal.get("applied"):
                data_quality["calibration"]["calibrated_models"] += 1
                if not data_quality["calibration"]["method"]:
                    data_quality["calibration"]["method"] = cal.get("method")
                if cal.get("partial"):
                    data_quality["calibration"]["partial_models"].append(mname)
            else:
                data_quality["calibration"]["uncalibrated_models"].append(mname)

        if data_quality["failed_models"]:
            logger.warning(
                "PREDICT_FALLBACK %d model(s) failed during ensemble run: %s",
                len(data_quality["failed_models"]),
                ", ".join(data_quality["failed_models"]),
            )
            data_quality["warnings"].append("model_failures")

        if models_used < (orchestrator._total_model_specs if orchestrator else 12):
            data_quality["warnings"].append("partial_ensemble")

        if data_quality["calibration"]["calibrated_models"] == 0:
            data_quality["warnings"].append("no_calibration")
        elif data_quality["calibration"]["uncalibrated_models"]:
            data_quality["warnings"].append("partial_calibration")

        # --- v4.6.2: per-model consensus + alternative bet ladder ---
        # Final 1X2 pick is the argmax of the ensemble probabilities, NOT
        # best_bet["best_side"] (which may be a non-1X2 market like over_2_5).
        final_1x2_pick = _argmax_side(home_prob, draw_prob, away_prob)
        model_consensus = compute_model_consensus(
            model_insights_payload,
            final_pick=final_1x2_pick,
            total_specs=getattr(orchestrator, "_total_model_specs", None),
        )
        alternative_bets = build_alternative_bets(
            best_bet, top_n=5, min_edge=0.0,
        )

        # --- Save prediction ---
        prediction = Prediction(
            request_hash=idempotency_key,
            match_id=db_match.id,
            user_id=user_id,
            home_prob=home_prob,
            draw_prob=draw_prob,
            away_prob=away_prob,
            over_25_prob=result.get("over_25_prob") or result.get("over_2_5_prob"),
            under_25_prob=result.get("under_25_prob") or result.get("under_2_5_prob"),
            btts_prob=result.get("btts_prob"),
            no_btts_prob=result.get("no_btts_prob"),
            # v4.6.1 — Asian Handicap + Correct Score
            ah_line=result.get("ah_line"),
            ah_home_prob=result.get("ah_home_prob"),
            ah_away_prob=result.get("ah_away_prob"),
            ah_lines=result.get("ah_lines"),
            cs_probs=result.get("cs_probs"),
            top_correct_score=result.get("top_correct_score"),
            top_cs_prob=result.get("top_cs_prob"),
            # v4.6.2 — consensus + alternatives
            model_consensus=model_consensus,
            alternative_bets=alternative_bets,
            consensus_prob=consensus_prob,
            final_ev=best_bet.get("edge", 0),
            recommended_stake=recommended_stake,
            model_weights=result.get("model_weights", {}),
            model_insights=model_insights_payload,
            confidence=confidence_val,
            bet_side=best_bet.get("best_side"),
            entry_odds=best_bet.get("odds", 2.0),
            raw_edge=best_bet.get("raw_edge", 0),
            normalized_edge=best_bet.get("edge", 0),
            vig_free_edge=best_bet.get("edge", 0),
        )
        db.add(prediction)
        await db.flush()
        await db.commit()

        logger.info(
            f"Prediction saved: fixture_id={fixture_id}, match={db_match.id}, "
            f"side={best_bet.get('best_side')}, "
            f"edge={best_bet.get('edge', 0):.4f}, "
            f"models={models_used}/{models_total}, "
            f"source={data_source}"
        )

        # C-1 — record the prediction against the daily limit
        if user_id is not None:
            from app.core.rate_limit import record_prediction as _record_pred
            _record_pred(user_id)

        # C-7 — calibration advisory note
        calibration_note: Optional[str] = None
        agreement_pct = float((model_consensus or {}).get("agreement_pct", 0.0))
        edge_val = float(best_bet.get("edge", 0.0))
        if confidence_val > 0.80 and agreement_pct < 0.60:
            calibration_note = "High confidence but low model agreement — treat with caution"
        elif edge_val > 0.05 and confidence_val < 0.55:
            calibration_note = "Good edge but low confidence — consider half-kelly staking"
        elif agreement_pct >= 0.75 and edge_val > 0.03:
            calibration_note = "Strong consensus signal"

        # --- Task System Integration ---
        # Trigger task progress updates for authenticated users
        if current_user and current_user.id:
            try:
                from app.modules.tasks.service import TaskService

                # Update "Make Your First Prediction" task
                await TaskService.update_task_progress(
                    db, current_user.id, 2, 1  # Task ID 2: "Make Your First Prediction"
                )

                # Update "Daily Predictions" task (if user has progress on it)
                await TaskService.update_task_progress(
                    db, current_user.id, 4, 1  # Task ID 4: "Daily Predictions"
                )

                # Update "Weekly Streaker" task
                await TaskService.update_task_progress(
                    db, current_user.id, 5, 1  # Task ID 5: "Weekly Streaker"
                )

                logger.info(f"Task progress updated for user {current_user.id} after prediction")
            except Exception as e:
                logger.warning(f"Task progress update failed (non-fatal): {e}")

        # --- CLV tracking ---
        # Record for ALL predictions that have a bet_side + valid odds (not just edge bets),
        # so every prediction gets profit/CLV tracking after settlement.
        if best_bet.get("best_side") and float(best_bet.get("odds", 0)) > 1.0:
            try:
                await CLVTracker.record_entry(
                    db, db_match.id, prediction.id,
                    best_bet["best_side"], best_bet["odds"]
                )
            except Exception as e:
                logger.warning(f"CLV record_entry failed (non-fatal): {e}")

        # --- Decision logging ---
        try:
            dl = DecisionLogger(db)
            await dl.log_decision(
                match_id=db_match.id,
                prediction_id=prediction.id,
                decision={
                    "type":          "bet",
                    "stake":         recommended_stake,
                    "odds":          best_bet.get("odds", 2.0),
                    "edge":          best_bet.get("edge", 0),
                    "reason":        f"{best_bet.get('best_side','?').upper()} @ {best_bet.get('odds',2.0):.2f} — edge {best_bet.get('edge',0):.2%}",
                    "model_weights": {p.get("model_name"): p.get("model_weight", 1.0)
                                      for p in individual_results},
                },
                context={
                    "market": {
                        "home_odds": home_odds, "draw_odds": draw_odds, "away_odds": away_odds,
                        "home_prob": home_prob, "draw_prob": draw_prob, "away_prob": away_prob,
                    },
                    "bankroll": {},
                },
            )
        except Exception as e:
            logger.warning(f"DecisionLogger failed (non-fatal): {e}")

        # --- v2.1.0: Send Telegram alert ---
        # Always send for edge > 2%, or when there's a clear prediction to share
        edge_value = best_bet.get("edge", 0)
        should_alert = (
            telegram_alerts
            and telegram_alerts.enabled
            and edge_value > MIN_EDGE_THRESHOLD
        )

        if should_alert:
            try:
                # v4.11.0 — surface the highest-weighted contributing model so
                # the alert body can credit it. Falls back gracefully when the
                # ensemble didn't return individual_results (vig-removal path).
                top_model_name = ""
                try:
                    contributors = [
                        p for p in (raw_result.get("individual_results") or [])
                        if not p.get("failed")
                    ]
                    if contributors:
                        top = max(
                            contributors,
                            key=lambda p: float(p.get("model_weight") or 0.0),
                        )
                        top_model_name = top.get("model_name") or ""
                except Exception:
                    top_model_name = ""

                # Risk score: orchestrator's entropy-derived value if present,
                # otherwise compute from the same probabilities so the alert
                # always shows a value when there are real probs.
                risk_value = float(
                    pred_data.get("risk_score")
                    if isinstance(pred_data, dict) else 0.0
                ) or 0.0
                if risk_value <= 0 and (home_prob + draw_prob + away_prob) > 0:
                    ent = 0.0
                    for p in (home_prob, draw_prob, away_prob):
                        if p > 0:
                            ent -= p * math.log(p)
                    risk_value = round(ent / math.log(3), 4)

                alert = BetAlert(
                    match_id=db_match.id,
                    home_team=match.home_team,
                    away_team=match.away_team,
                    prediction=best_bet.get("best_side", "none"),
                    probability=consensus_prob,
                    edge=edge_value,
                    stake=recommended_stake,
                    odds=best_bet.get("odds", 2.0),
                    confidence=confidence_val,
                    kickoff_time=naive_kickoff,
                    # v2.1.0 fields
                    home_prob=home_prob,
                    draw_prob=draw_prob,
                    away_prob=away_prob,
                    home_odds=home_odds,
                    draw_odds=draw_odds,
                    away_odds=away_odds,
                    models_used=models_used,
                    models_total=models_total,
                    data_source=data_source,
                    # v4.11.0 fields — richer message body
                    league=match.league or "",
                    fixture_id=str(match.fixture_id) if match.fixture_id else None,
                    over_25_prob=float(result.get("over_25_prob") or result.get("over_2_5_prob") or 0.0),
                    btts_prob=float(result.get("btts_prob") or 0.0),
                    vig_free_edge=float(prediction.vig_free_edge or 0.0),
                    risk_score=risk_value,
                    top_model=top_model_name,
                    data_quality=data_quality,
                    app_url=os.getenv("PUBLIC_APP_URL", ""),
                )
                await telegram_alerts.send_bet_alert(alert)
                logger.info(
                    f"Alert sent: {match.home_team} vs {match.away_team} "
                    f"edge={edge_value:.2%}"
                )
            except Exception as e:
                logger.warning(f"Telegram alert failed (non-fatal): {e}")

        response = build_prediction_response(
            prediction, db_match, orchestrator, data_quality, data_source=data_source
        )
        response.calibration_note = calibration_note
        return response

    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error: {e}")
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        logger.error(f"Prediction failed: {e}", exc_info=True)
        await db.rollback()
        raise HTTPException(status_code=500, detail="Prediction failed. Please verify the match data and try again.")


@router.get("/value-intelligence")
async def value_intelligence_feed(
    limit: int = 20,
    min_vit: float = 25.0,
    tier: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
):
    """
    Return recent predictions ranked by VIT (Value Intelligence Trust) score.

    The VIT score is a composite of:
      • Value       (40%) — vig-free edge over market
      • Intelligence (35%) — model ensemble agreement %
      • Trust       (25%) — calibrated confidence
    """
    from sqlalchemy import desc as _desc
    rows = (await db.execute(
        select(Prediction, Match)
        .join(Match, Match.id == Prediction.match_id)
        .order_by(_desc(Prediction.timestamp))
        .limit(200)
    )).all()

    results = []
    for pred, match in rows:
        _mc2 = pred.model_consensus or {}
        agreement_pct = float(_mc2.get("agreement_pct", 0.0))
        _mv = int(_mc2.get("voted_models", 0))
        _tm = int(_mc2.get("total_models", 13))
        # Recency: compute how many hours old this prediction is
        import datetime as _dt
        _now = _dt.datetime.utcnow()
        if pred.timestamp:
            _ts = pred.timestamp if pred.timestamp.tzinfo is None else pred.timestamp.replace(tzinfo=None)
            _age_h = max(0.0, (_now - _ts).total_seconds() / 3600.0)
        else:
            _age_h = 0.0
        vit = compute_vit_score(
            pred.vig_free_edge or 0,
            agreement_pct,
            pred.confidence or 0,
            home_prob=float(pred.home_prob or 0),
            draw_prob=float(pred.draw_prob or 0),
            away_prob=float(pred.away_prob or 0),
            models_voted=_mv,
            total_models=_tm,
            prediction_age_hours=_age_h,
        )
        score = vit["vit_score"]
        vtier = vit["vit_tier"]

        if score < min_vit:
            continue
        if tier and vtier != tier.upper():
            continue

        results.append({
            "prediction_id":   pred.id,
            "match_id":        pred.match_id,
            "home_team":       match.home_team,
            "away_team":       match.away_team,
            "league":          match.league,
            "kickoff_time":    match.kickoff_time.isoformat() if match.kickoff_time else None,
            "actual_outcome":  match.actual_outcome,
            "home_prob":       round(float(pred.home_prob or 0), 4),
            "draw_prob":       round(float(pred.draw_prob or 0), 4),
            "away_prob":       round(float(pred.away_prob or 0), 4),
            "over_25_prob":    round(float(pred.over_25_prob or 0), 4),
            "btts_prob":       round(float(pred.btts_prob or 0), 4),
            "bet_side":        pred.bet_side,
            "entry_odds":      round(float(pred.entry_odds or 0), 3),
            "edge":            round(float(pred.vig_free_edge or 0), 4),
            "confidence":      round(float(pred.confidence or 0), 4),
            "recommended_stake": round(float(pred.recommended_stake or 0), 4),
            "agreement_pct":   round(agreement_pct, 4),
            "vit_score":       score,
            "vit_tier":        vtier,
            "vit_components":  vit["vit_components"],
            "has_market_odds": vit.get("has_market_odds", False),
            "prediction_age_hours": round(_age_h, 1),
            "timestamp":       pred.timestamp.isoformat() if pred.timestamp else None,
        })

    results.sort(key=lambda r: r["vit_score"], reverse=True)
    results = results[:limit]

    tier_counts: dict = {}
    for r in results:
        tier_counts[r["vit_tier"]] = tier_counts.get(r["vit_tier"], 0) + 1

    return {
        "total":       len(results),
        "tier_counts": tier_counts,
        "predictions": results,
    }


@router.get("/{match_id}/insights")
async def get_match_insights(
    match_id: int,
    db: AsyncSession = Depends(get_db),
):
    """
    Generate AI tactical insights for a specific prediction.
    Returns {gemini, claude, grok} format.
    Falls back to ML-derived synthetic insight when no AI keys are configured.
    """
    import os as _os
    from app.db.models import Match, Prediction
    from app.services.gemini_insights import generate_match_insights

    match_row = await db.execute(select(Match).where(Match.id == match_id))
    match = match_row.scalar_one_or_none()
    if not match:
        raise HTTPException(status_code=404, detail="Match not found")

    pred_row = await db.execute(
        select(Prediction)
        .where(Prediction.match_id == match_id)
        .order_by(Prediction.timestamp.desc())
        .limit(1)
    )
    pred = pred_row.scalars().first()
    if not pred:
        # No prior prediction — return a synthetic market-implied insight so
        # the frontend never gets a hard 404 when visiting the insights tab
        # before submitting a prediction.
        synthetic_no_pred = {
            "summary": (
                f"No prediction has been submitted yet for "
                f"{match.home_team} vs {match.away_team}. "
                "Submit a prediction to unlock AI-powered tactical insights."
            ),
            "key_factors": [
                "Match has not been analysed yet",
                "Submit a prediction to trigger the 13-model ensemble",
                "AI insights will appear here once the prediction is ready",
            ],
            "recommendation": "Run the prediction first via the Predict tab.",
            "confidence": 0.0,
            "provider": "system",
        }
        return {
            "match_id": match_id,
            "gemini": synthetic_no_pred,
            "claude": None,
            "grok": None,
            "source": "no_prediction",
        }

    conf = float(pred.confidence) if isinstance(pred.confidence, (int, float)) else 0.5
    home_p = float(pred.home_prob or 0.33)
    draw_p = float(pred.draw_prob or 0.33)
    away_p = float(pred.away_prob or 0.34)
    edge_val = float(pred.vig_free_edge or 0.0)
    over25 = float(pred.over_25_prob or 0.0)
    btts = float(pred.btts_prob or 0.0)
    bet_side = pred.bet_side or "home"

    gemini_key = _os.getenv("GEMINI_API_KEY", "").strip()

    if not gemini_key:
        # ML ensemble fallback — generate rule-based insight from prediction data
        probs = {"home": home_p, "draw": draw_p, "away": away_p}
        leader = max(probs, key=probs.get)
        leader_prob = probs[leader]
        side_label = bet_side.upper()
        synthetic_insight = {
            "summary": (
                f"ML ensemble analysis for {match.home_team} vs {match.away_team}. "
                f"Home win probability: {home_p * 100:.1f}%, "
                f"Draw: {draw_p * 100:.1f}%, "
                f"Away: {away_p * 100:.1f}%. "
                f"The {leader} outcome leads with {leader_prob * 100:.1f}% probability."
            ),
            "key_factors": [
                f"Detected edge: {edge_val * 100:.2f}% above market implied probability",
                f"Over 2.5 goals probability: {over25 * 100:.1f}%",
                f"BTTS probability: {btts * 100:.1f}%",
                "Based on 13-model differentiated statistical ensemble",
            ],
            "recommendation": f"Back {side_label} — {edge_val * 100:.2f}% edge detected at {float(pred.entry_odds or 2.0):.2f}",
            "confidence": conf,
            "provider": "ml_ensemble",
        }
        return {
            "match_id": match_id,
            "gemini": synthetic_insight,
            "claude": None,
            "grok": None,
            "source": "ml_fallback",
        }

    raw = await generate_match_insights(
        home_team=match.home_team,
        away_team=match.away_team,
        league=match.league or "unknown",
        home_prob=home_p,
        draw_prob=draw_p,
        away_prob=away_p,
        over_25_prob=pred.over_25_prob,
        btts_prob=pred.btts_prob,
        bet_side=bet_side,
        edge=edge_val,
        entry_odds=pred.entry_odds,
        confidence=conf,
    )

    gemini_insight = {
        "summary": raw.get("summary"),
        "key_factors": raw.get("key_factors", []),
        "recommendation": raw.get("value_assessment"),
        "confidence": conf,
        "provider": raw.get("source", "vit-statistical-engine"),
    }

    return {
        "match_id": match_id,
        "gemini": gemini_insight,
        "claude": None,
        "grok": None,
        "source": raw.get("source", "vit-statistical-engine"),
    }
