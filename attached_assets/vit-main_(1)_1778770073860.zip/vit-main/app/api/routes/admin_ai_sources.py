"""Admin/Analyst AI Sources panel — upload raw Claude/Grok/etc analysis per match."""

import json
import logging
import re
from datetime import datetime, timezone
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field, validator
from sqlalchemy import select, desc
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import get_db
from app.db.models import AIPrediction, AIPerformance, Match, User
from app.services.ai_ingestion import AIIngestionService
from app.auth.dependencies import get_current_user

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/admin/ai-sources", tags=["admin-ai-sources"])


ALLOWED_SOURCES = {
    "chatgpt", "gemini", "claude", "grok",
    "deepseek", "perplexity", "mistral", "manual", "server",
}
ALLOWED_TIERS = {"analyst", "pro", "elite"}

MATCH_ANALYSIS_SYSTEM = (
    "You are a sharp professional football betting analyst with deep expertise in statistical "
    "modelling, team form cycles, squad availability, tactical matchups, and market efficiency. "
    "You provide precise, evidence-based probability estimates. "
    "CRITICAL: You MUST respond with ONLY a raw JSON object — no markdown, no code fences, "
    "no explanations outside the JSON."
)


def _can_upload(user: User) -> bool:
    if getattr(user, "role", None) == "admin":
        return True
    tier = (getattr(user, "subscription_tier", "") or "").lower()
    return tier in ALLOWED_TIERS


async def require_uploader(current_user: User = Depends(get_current_user)) -> User:
    if not _can_upload(current_user):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="AI source uploads require an admin account or analyst+ subscription tier",
        )
    return current_user


class AISourceIngestPayload(BaseModel):
    match_id: int = Field(..., gt=0)
    source: str = Field(..., min_length=2, max_length=50)
    home_prob: float = Field(..., ge=0.0, le=1.0)
    draw_prob: float = Field(..., ge=0.0, le=1.0)
    away_prob: float = Field(..., ge=0.0, le=1.0)
    confidence: float = Field(0.7, ge=0.0, le=1.0)
    reason: Optional[str] = Field(None, max_length=500)
    raw_content: Optional[str] = Field(None, max_length=20000)

    @validator("source")
    def _src(cls, v: str) -> str:
        v = v.lower().strip()
        if v not in ALLOWED_SOURCES:
            raise ValueError(
                f"Source must be one of: {sorted(ALLOWED_SOURCES)}"
            )
        return v

    @validator("away_prob")
    def _sum_check(cls, v, values):
        h = values.get("home_prob", 0.0)
        d = values.get("draw_prob", 0.0)
        total = (h or 0) + (d or 0) + (v or 0)
        if total <= 0:
            raise ValueError("Probabilities must sum to a positive value")
        if abs(total - 1.0) > 0.1:
            raise ValueError(
                f"home + draw + away probabilities should be close to 1.0 (got {total:.3f})"
            )
        return v


@router.get("/permissions")
async def my_permissions(current_user: User = Depends(get_current_user)):
    """Tell the frontend whether the current user can upload AI sources."""
    return {
        "can_upload": _can_upload(current_user),
        "role": getattr(current_user, "role", "user"),
        "tier": getattr(current_user, "subscription_tier", "viewer"),
        "allowed_sources": sorted(ALLOWED_SOURCES),
    }


@router.get("/matches")
async def list_matches_for_ingest(
    limit: int = 30,
    db: AsyncSession = Depends(get_db),
    _user: User = Depends(require_uploader),
):
    """List upcoming/live matches only (no past fixtures) with AI source coverage."""
    from datetime import timedelta
    now = datetime.now(timezone.utc)
    live_cutoff = now - timedelta(hours=3)

    res = await db.execute(
        select(Match)
        .where(
            Match.status.in_(["scheduled", "upcoming", "live", "in_progress"]),
            Match.kickoff_time >= live_cutoff,
        )
        .order_by(Match.kickoff_time.asc())
        .limit(max(1, min(limit, 100)))
    )
    matches = res.scalars().all()
    if not matches:
        res = await db.execute(
            select(Match)
            .where(Match.kickoff_time >= live_cutoff)
            .order_by(Match.kickoff_time.asc())
            .limit(limit)
        )
        matches = res.scalars().all()

    match_ids = [m.id for m in matches]
    coverage: dict[int, list[str]] = {mid: [] for mid in match_ids}
    if match_ids:
        cov_res = await db.execute(
            select(AIPrediction.match_id, AIPrediction.source).where(
                AIPrediction.match_id.in_(match_ids)
            )
        )
        for mid, src in cov_res.all():
            coverage.setdefault(mid, []).append(src)

    return {
        "matches": [
            {
                "id": m.id,
                "home_team": m.home_team,
                "away_team": m.away_team,
                "league": m.league,
                "match_date": m.kickoff_time.isoformat() if m.kickoff_time else None,
                "status": m.status,
                "sources": sorted(set(coverage.get(m.id, []))),
            }
            for m in matches
        ]
    }


@router.get("/performance")
async def get_ai_performance(
    db: AsyncSession = Depends(get_db),
    _user: User = Depends(require_uploader),
):
    """Get performance metrics for all AI sources."""
    res = await db.execute(
        select(AIPerformance).order_by(desc(AIPerformance.accuracy))
    )
    perfs = res.scalars().all()

    total_res = await db.execute(select(AIPrediction))
    all_preds = total_res.scalars().all()
    counts: dict[str, int] = {}
    for p in all_preds:
        counts[p.source] = counts.get(p.source, 0) + 1

    if not perfs:
        sources_with_data = set(counts.keys())
        return {
            "performance": [],
            "total_ingested": len(all_preds),
            "source_counts": counts,
            "message": "No performance data yet — metrics are computed after matches settle",
        }

    return {
        "performance": [
            {
                "source": p.source,
                "accuracy": round(p.accuracy or 0.0, 4),
                "calibration_score": round(p.calibration_score or 0.0, 4),
                "sample_size": p.sample_size or 0,
                "total_predictions": p.total_predictions or 0,
                "current_weight": round(p.current_weight or 1.0, 4),
                "bias_home": round(p.bias_home_overrate or 0.0, 4),
                "bias_draw": round(p.bias_draw_overrate or 0.0, 4),
                "bias_away": round(p.bias_away_overrate or 0.0, 4),
                "certified": bool(p.certified),
                "last_updated": p.last_updated.isoformat() if p.last_updated else None,
                "ingested_count": counts.get(p.source, 0),
            }
            for p in perfs
        ],
        "total_ingested": len(all_preds),
        "source_counts": counts,
    }


@router.post("/update-performance")
async def trigger_performance_update(
    db: AsyncSession = Depends(get_db),
    _user: User = Depends(require_uploader),
):
    """Manually trigger AI performance metric recalculation based on settled matches."""
    service = AIIngestionService(db)
    await service.update_performance_metrics()
    return {"status": "ok", "message": "Performance metrics recalculated"}


class ServerAnalysisPayload(BaseModel):
    limit: int = Field(20, ge=1, le=50)
    source_label: str = Field("server", description="Source label for ingested predictions")


def _build_match_prompt(home: str, away: str, league: str) -> str:
    return (
        f"Analyze this football match and provide your independent probability assessment.\n\n"
        f"Match: {home} vs {away}\n"
        f"League: {league}\n\n"
        f"Provide your analysis as a raw JSON object (no markdown, no code fences):\n"
        f'{{\n'
        f'  "home_prob": 0.00,\n'
        f'  "draw_prob": 0.00,\n'
        f'  "away_prob": 0.00,\n'
        f'  "confidence": 0.00,\n'
        f'  "reason": "one-line tactical summary (max 120 chars)"\n'
        f'}}\n\n'
        f"Rules:\n"
        f"- home_prob + draw_prob + away_prob MUST equal exactly 1.0\n"
        f"- confidence: 0.5 = uncertain, 0.65 = moderate, 0.80 = high conviction\n"
        f"- reason: concise tactical reasoning, no filler\n"
        f"- Return ONLY the JSON object, nothing else"
    )


def _parse_ai_json(raw: str, home_default=0.34, draw_default=0.33, away_default=0.33):
    """Parse JSON from AI response, stripping code fences if present."""
    text = raw.strip()
    fence = re.search(r"```(?:json)?\s*([\s\S]*?)```", text)
    if fence:
        text = fence.group(1).strip()
    obj = re.search(r"\{[\s\S]*\}", text)
    if obj:
        text = obj.group(0)
    parsed = json.loads(text)
    h = max(0.0, float(parsed.get("home_prob", home_default)))
    d = max(0.0, float(parsed.get("draw_prob", draw_default)))
    a = max(0.0, float(parsed.get("away_prob", away_default)))
    total = h + d + a or 1.0
    return {
        "home_prob": round(h / total, 4),
        "draw_prob": round(d / total, 4),
        "away_prob": round(a / total, 4),
        "confidence": min(1.0, max(0.3, float(parsed.get("confidence", 0.65)))),
        "reason": str(parsed.get("reason", "Server AI analysis"))[:500],
        "raw_content": raw,
    }


async def _ml_ensemble_fallback(
    db: AsyncSession,
    match_id: int,
    home: str,
    away: str,
    league: str,
) -> Optional[dict]:
    """
    Use the platform's 13-model ML ensemble to generate predictions when
    all external AI providers are unavailable.  Returns an analysis dict
    (home_prob, draw_prob, away_prob, confidence, reason, raw_content)
    or None if the orchestrator is not ready.
    """
    try:
        from app.core.dependencies import get_orchestrator
        from app.services.predict_features import build_predict_features
        from app.modules.ai.orchestrator import generate_ai_prediction

        orch = get_orchestrator()
        if orch is None or orch.num_models_ready() == 0:
            return None

        features = await build_predict_features(db, home, away, league)
        features["home_team"] = home
        features["away_team"] = away
        features["league"]    = league

        result = await generate_ai_prediction(
            features=features,
            match_id=str(match_id),
            orchestrator=orch,
            db=db,
            triggered_by="server-analysis-ml-fallback",
        )

        preds = result.get("predictions", {})
        hp = float(preds.get("home_prob", 0.34))
        dp = float(preds.get("draw_prob", 0.33))
        ap = float(preds.get("away_prob", 0.33))

        # Normalise
        total = hp + dp + ap or 1.0
        hp, dp, ap = round(hp / total, 4), round(dp / total, 4), round(ap / total, 4)

        # Derive confidence from model_agreement or entropy
        agreement = preds.get("model_agreement")
        conf_1x2  = (preds.get("confidence") or {}).get("1x2") if isinstance(preds.get("confidence"), dict) else preds.get("confidence")
        confidence = float(conf_1x2 or agreement or 0.62)
        confidence = min(0.95, max(0.40, confidence))

        n_models   = result.get("models_used", orch.num_models_ready())
        completeness = features.get("feature_completeness")
        comp_str   = f" | completeness={completeness:.0%}" if completeness is not None else ""
        reason     = (
            f"13-model ML ensemble ({n_models} active){comp_str} — "
            f"AI cascade unavailable, predictions from statistical models"
        )

        return {
            "home_prob":   hp,
            "draw_prob":   dp,
            "away_prob":   ap,
            "confidence":  round(confidence, 4),
            "reason":      reason[:500],
            "raw_content": json.dumps({"source": "ml_ensemble", "predictions": preds}),
        }
    except Exception as exc:
        logger.warning("[server-analysis] ML fallback failed for match=%s: %s", match_id, exc)
        return None


@router.post("/run-server")
async def run_server_analysis(
    payload: ServerAnalysisPayload,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(require_uploader),
):
    """
    Run server-side AI analysis on upcoming matches using:
      1. Built-in AI cascade  (Gemini → Claude → OpenAI → Grok)
      2. 13-model ML ensemble fallback when all AI providers are unavailable

    Always produces predictions — never returns "No AI provider available"
    when the ML ensemble is loaded and ready.
    """
    from datetime import timedelta
    from app.services.ai_client import call_ai

    now = datetime.now(timezone.utc)
    live_cutoff = now - timedelta(hours=3)

    res = await db.execute(
        select(Match)
        .where(
            Match.status.in_(["scheduled", "upcoming", "live", "in_progress"]),
            Match.kickoff_time >= live_cutoff,
        )
        .order_by(Match.kickoff_time.asc())
        .limit(payload.limit)
    )
    matches = res.scalars().all()
    if not matches:
        res = await db.execute(
            select(Match)
            .where(Match.kickoff_time >= live_cutoff)
            .order_by(Match.kickoff_time.asc())
            .limit(payload.limit)
        )
        matches = res.scalars().all()

    if not matches:
        return {"status": "no_matches", "processed": 0, "results": []}

    service = AIIngestionService(db)
    results = []
    source_label = payload.source_label.lower().strip() or "server"
    if source_label not in ALLOWED_SOURCES:
        source_label = "server"

    for match in matches:
        home = match.home_team or "Home"
        away = match.away_team or "Away"
        league = match.league or "Unknown League"
        prompt = _build_match_prompt(home, away, league)

        try:
            # ── Step 1: try the external AI cascade ──────────────────────────
            raw = await call_ai(
                prompt=f"{MATCH_ANALYSIS_SYSTEM}\n\n{prompt}",
                max_tokens=300,
                temperature=0.2,
            )

            if raw:
                analysis = _parse_ai_json(raw)
                method = "ai_cascade"
            else:
                # ── Step 2: ML ensemble fallback ─────────────────────────────
                logger.info(
                    "[server-analysis] AI cascade unavailable for %s vs %s — trying ML ensemble",
                    home, away,
                )
                analysis = await _ml_ensemble_fallback(db, match.id, home, away, league)
                method = "ml_ensemble"

            if not analysis:
                try:
                    from app.services.deterministic_insights import generate_deterministic_insights
                    det = generate_deterministic_insights(
                        home_team=home, away_team=away,
                        league=league or "default",
                        home_prob=0.45, draw_prob=0.26, away_prob=0.29,
                        confidence=0.5,
                    )
                    analysis = {
                        "home_prob": det["home_prob"],
                        "draw_prob": det["draw_prob"],
                        "away_prob": det["away_prob"],
                        "confidence": det["confidence"],
                        "reason": det.get("summary") or f"VIT Statistical Engine baseline for {home} vs {away}.",
                        "raw_content": str(det),
                    }
                    method = "scie_deterministic"
                except Exception as scie_exc:
                    logger.warning("[server-analysis] SCIE fallback failed for %s vs %s: %s", home, away, scie_exc)
                    results.append({
                        "match_id": match.id,
                        "match": f"{home} vs {away}",
                        "status": "skipped",
                        "error": "Statistical engine fallback failed — match skipped",
                    })
                    continue

            ok = await service.ingest_prediction(
                match_id=match.id,
                source=source_label,
                home_prob=analysis["home_prob"],
                draw_prob=analysis["draw_prob"],
                away_prob=analysis["away_prob"],
                confidence=analysis["confidence"],
                reason=analysis["reason"],
                raw_content=analysis["raw_content"],
                submitted_by=user.id,
            )
            results.append({
                "match_id": match.id,
                "match": f"{home} vs {away}",
                "status": "ingested" if ok else "failed",
                "home_prob": analysis["home_prob"],
                "draw_prob": analysis["draw_prob"],
                "away_prob": analysis["away_prob"],
                "confidence": analysis["confidence"],
                "reason": analysis["reason"],
                "method": method,
            })
            logger.info(
                "[server-analysis] %s vs %s [%s] → %.0f/%.0f/%.0f conf=%.2f",
                home, away, method,
                analysis["home_prob"] * 100,
                analysis["draw_prob"] * 100,
                analysis["away_prob"] * 100,
                analysis["confidence"],
            )
        except (json.JSONDecodeError, ValueError, KeyError) as parse_err:
            results.append({
                "match_id": match.id,
                "match": f"{home} vs {away}",
                "status": "parse_error",
                "error": str(parse_err)[:200],
            })
        except Exception as exc:
            logger.warning("[server-analysis] match=%s error=%s", match.id, exc)
            results.append({
                "match_id": match.id,
                "match": f"{home} vs {away}",
                "status": "error",
                "error": str(exc)[:200],
            })

    ingested = sum(1 for r in results if r.get("status") == "ingested")
    ml_used  = sum(1 for r in results if r.get("method") == "ml_ensemble")
    return {
        "status": "done",
        "processed": len(results),
        "ingested": ingested,
        "skipped": len(results) - ingested,
        "ml_fallback_used": ml_used,
        "results": results,
    }


@router.get("/match/{match_id}")
async def list_sources_for_match(
    match_id: int,
    db: AsyncSession = Depends(get_db),
    _user: User = Depends(require_uploader),
):
    """All uploaded AI sources for a single match."""
    match_row = await db.execute(select(Match).where(Match.id == match_id))
    match = match_row.scalar_one_or_none()
    if not match:
        raise HTTPException(status_code=404, detail="Match not found")

    rows = await db.execute(
        select(AIPrediction)
        .where(AIPrediction.match_id == match_id)
        .order_by(desc(AIPrediction.timestamp))
    )
    preds = rows.scalars().all()

    return {
        "match": {
            "id": match.id,
            "home_team": match.home_team,
            "away_team": match.away_team,
            "league": match.league,
            "match_date": match.kickoff_time.isoformat() if match.kickoff_time else None,
            "status": match.status,
        },
        "predictions": [
            {
                "id": p.id,
                "source": p.source,
                "home_prob": p.home_prob,
                "draw_prob": p.draw_prob,
                "away_prob": p.away_prob,
                "confidence": p.confidence,
                "reason": p.reason,
                "raw_content": p.raw_content,
                "submitted_by": p.submitted_by,
                "is_certified": bool(p.is_certified),
                "was_correct": p.was_correct,
                "timestamp": p.timestamp.isoformat() if p.timestamp else None,
            }
            for p in preds
        ],
    }


@router.post("/ingest")
async def ingest_source(
    payload: AISourceIngestPayload,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(require_uploader),
):
    """Upload (or update) a single match's AI analysis from Claude/Grok/etc."""
    match_row = await db.execute(select(Match).where(Match.id == payload.match_id))
    match = match_row.scalar_one_or_none()
    if not match:
        raise HTTPException(status_code=404, detail="Match not found")

    service = AIIngestionService(db)
    ok = await service.ingest_prediction(
        match_id=payload.match_id,
        source=payload.source,
        home_prob=payload.home_prob,
        draw_prob=payload.draw_prob,
        away_prob=payload.away_prob,
        confidence=payload.confidence,
        reason=payload.reason,
        raw_content=payload.raw_content,
        submitted_by=user.id,
    )
    if not ok:
        raise HTTPException(status_code=400, detail="Failed to ingest AI source")

    logger.info(
        "AI source uploaded: match=%s source=%s by user=%s",
        payload.match_id, payload.source, user.id,
    )
    return {"status": "success", "match_id": payload.match_id, "source": payload.source}


@router.delete("/{prediction_id}")
async def delete_source(
    prediction_id: int,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(require_uploader),
):
    """Delete an uploaded AI source. Admins can delete any; analysts only their own."""
    row = await db.execute(select(AIPrediction).where(AIPrediction.id == prediction_id))
    pred = row.scalar_one_or_none()
    if not pred:
        raise HTTPException(status_code=404, detail="AI prediction not found")

    is_admin = getattr(user, "role", None) == "admin"
    if not is_admin and pred.submitted_by != user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You can only delete AI sources you uploaded",
        )

    await db.delete(pred)
    await db.commit()
    return {"status": "deleted", "id": prediction_id}
