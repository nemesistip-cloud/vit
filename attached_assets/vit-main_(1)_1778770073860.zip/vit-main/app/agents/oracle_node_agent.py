"""Oracle Node Agent — acts as an internal VIT oracle node.

Monitors matches with known results in DB and submits them to the oracle
consensus system as source "vit-node-internal". Tracks contribution to
the network via NodeActivity records.

Interval: 10 minutes
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict

from sqlalchemy import select

from app.agents.base import BaseAgent
from app.db.database import AsyncSessionLocal
from app.db.models import Match
from app.modules.blockchain.models import OracleResult, ConsensusPrediction, ConsensusStatus
from app.modules.blockchain.settlement import settle_match
from app.modules.network.models import NodeActivity

logger = logging.getLogger(__name__)

_NODE_ID = "did:vit:agent:oracle-node"
_SOURCE = "vit-node-internal"
_MIN_AGREEMENT = 1   # single internal node is sufficient for auto-acceptance


class OracleNodeAgent(BaseAgent):
    """Submits confirmed match results to the oracle consensus engine."""

    def __init__(self) -> None:
        super().__init__(
            name="oracle-node",
            interval_seconds=600,   # 10 minutes
            initial_delay_seconds=45,
        )
        self.submitted_count = 0
        self.settled_count = 0

    async def run_cycle(self) -> Dict[str, Any]:
        async with AsyncSessionLocal() as db:
            return await self._process(db)

    async def _process(self, db) -> Dict[str, Any]:
        # Find settled/finished matches with actual_outcome that don't already have
        # a vit-node-internal oracle submission. No lookback cap — process all history.
        finished_res = await db.execute(
            select(Match).where(
                Match.actual_outcome.isnot(None),
                Match.status.in_(["finished", "settled"]),
            ).limit(50)
        )
        finished_matches = finished_res.scalars().all()

        submitted = 0
        settled = 0
        skipped = 0

        import uuid as _uuid_mod
        from decimal import Decimal as _Dec

        for match in finished_matches:
            match_id = str(match.id)
            try:
                async with db.begin_nested():
                    # Check already submitted by this node
                    existing_res = await db.execute(
                        select(OracleResult).where(
                            OracleResult.match_id == match_id,
                            OracleResult.source == _SOURCE,
                        )
                    )
                    already_submitted = existing_res.scalar_one_or_none() is not None

                    if not already_submitted:
                        oracle_rec = OracleResult(
                            match_id=match_id,
                            source=_SOURCE,
                            home_score=match.home_goals or 0,
                            away_score=match.away_goals or 0,
                            result=match.actual_outcome,
                            submitted_at=datetime.now(timezone.utc),
                        )
                        db.add(oracle_rec)
                        await db.flush()
                        submitted += 1
                    else:
                        skipped += 1

                    # --- Consensus + settlement (runs for both new and previously submitted) ---
                    all_res = await db.execute(
                        select(OracleResult).where(OracleResult.match_id == match_id)
                    )
                    all_oracle = all_res.scalars().all()

                    outcome_counts: dict[str, int] = {}
                    for r in all_oracle:
                        outcome_counts[r.result] = outcome_counts.get(r.result, 0) + 1

                    agreed: str | None = None
                    for ov, cnt in outcome_counts.items():
                        if cnt >= _MIN_AGREEMENT:
                            agreed = ov
                            break

                    if not agreed:
                        continue

                    for r in all_oracle:
                        r.is_accepted = r.result == agreed
                    await db.flush()

                    cp_res = await db.execute(
                        select(ConsensusPrediction).where(
                            ConsensusPrediction.match_id == match_id
                        )
                    )
                    cp = cp_res.scalar_one_or_none()

                    # Auto-create a ConsensusPrediction if none exists yet so
                    # settle_match can proceed (it requires the row to exist).
                    if cp is None:
                        p_home = _Dec("0.3333")
                        p_draw = _Dec("0.3334")
                        p_away = _Dec("0.3333")
                        if agreed == "home":
                            p_home, p_draw, p_away = _Dec("0.6"), _Dec("0.2"), _Dec("0.2")
                        elif agreed == "away":
                            p_home, p_draw, p_away = _Dec("0.2"), _Dec("0.2"), _Dec("0.6")
                        elif agreed == "draw":
                            p_home, p_draw, p_away = _Dec("0.25"), _Dec("0.5"), _Dec("0.25")
                        cp = ConsensusPrediction(
                            id=str(_uuid_mod.uuid4()),
                            match_id=match_id,
                            ai_p_home=p_home,
                            ai_p_draw=p_draw,
                            ai_p_away=p_away,
                            ai_confidence=_Dec("0.7"),
                            ai_risk=_Dec("0.3"),
                            consensus_p_home=p_home,
                            consensus_p_draw=p_draw,
                            consensus_p_away=p_away,
                            final_p_home=p_home,
                            final_p_draw=p_draw,
                            final_p_away=p_away,
                            validator_count=1,
                            total_influence=_Dec("1"),
                            status=ConsensusStatus.OPEN.value,
                        )
                        db.add(cp)
                        await db.flush()

                    if cp.status not in (
                        ConsensusStatus.SETTLED.value,
                        ConsensusStatus.VOIDED.value,
                    ):
                        await settle_match(match_id, agreed, db)
                        settled += 1
                        logger.info(
                            "[oracle-node] settled match %s → %s", match_id, agreed
                        )
            except Exception as exc:
                logger.warning(
                    "[oracle-node] failed processing match %s: %s", match_id, exc
                )

        # Record network contribution
        if submitted > 0:
            self.submitted_count += submitted
            self.settled_count += settled
            activity = NodeActivity(
                node_id=_NODE_ID,
                node_name="oracle-node",
                node_type="agent",
                activity_type="oracle_submit",
                contribution_score=float(submitted) * 2.0,
                activity_meta={
                    "submitted": submitted,
                    "settled": settled,
                    "skipped": skipped,
                    "cycle": self.run_count,
                },
            )
            db.add(activity)

        await db.commit()

        result = {
            "submitted": submitted,
            "settled": settled,
            "skipped": skipped,
            "lifetime_submitted": self.submitted_count,
            "lifetime_settled": self.settled_count,
        }
        logger.info("[oracle-node] cycle complete: %s", result)
        return result
