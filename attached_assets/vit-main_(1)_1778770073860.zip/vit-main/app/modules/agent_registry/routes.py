"""AI Agent Registry Routes — register, manage, track performance."""
from __future__ import annotations

from decimal import Decimal
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import get_db
from app.modules.agent_registry.models import AgentStatus
from app.modules.agent_registry.service import (
    activate_agent,
    add_payment_route,
    bootstrap_agent_registry,
    get_agent_stats,
    issue_credential,
    list_agents,
    record_agent_task,
    register_agent,
)

router = APIRouter(prefix="/api/agents/registry", tags=["agent-registry"])


class RegisterAgentRequest(BaseModel):
    agent_id: str
    name: str
    capabilities: list[str] = Field(default_factory=list)
    description: Optional[str] = None
    owner_user_id: Optional[int] = None
    endpoint_url: Optional[str] = None
    public_key: Optional[str] = None
    initial_stake: float = 0.0


class RecordTaskRequest(BaseModel):
    task_type: str
    success: bool
    latency_ms: Optional[int] = None
    accuracy: Optional[float] = None
    vit_earned: float = 0.0
    task_ref: Optional[str] = None
    notes: Optional[str] = None


class IssueCredentialRequest(BaseModel):
    credential_type: str
    issued_by: Optional[str] = None
    valid_days: int = 365


class PaymentRouteRequest(BaseModel):
    route_type: str
    recipient_address: str
    split_pct: float = 100.0


@router.post("/bootstrap")
async def bootstrap(db: AsyncSession = Depends(get_db)):
    count = await bootstrap_agent_registry(db)
    return {"created": count, "message": f"Bootstrapped {count} built-in agents"}


@router.get("/stats")
async def agent_stats(db: AsyncSession = Depends(get_db)):
    return await get_agent_stats(db)


@router.get("/")
async def list_all_agents(
    status: Optional[AgentStatus] = None,
    limit: int = 50,
    db: AsyncSession = Depends(get_db),
):
    agents = await list_agents(db, status=status, limit=limit)
    return {
        "agents": [
            {
                "agent_id": a.agent_id,
                "name": a.name,
                "status": a.status.value,
                "capabilities": a.capabilities,
                "did_identifier": a.did_identifier,
                "reputation_score": float(a.reputation_score),
                "accuracy_rate": float(a.accuracy_rate),
                "total_tasks": a.total_tasks,
                "successful_tasks": a.successful_tasks,
                "total_earned_vit": float(a.total_earned_vit),
                "is_builtin": a.is_builtin,
                "version": a.version,
                "last_active_at": a.last_active_at.isoformat() if a.last_active_at else None,
            }
            for a in agents
        ],
        "total": len(agents),
    }


@router.post("/register")
async def register(req: RegisterAgentRequest, db: AsyncSession = Depends(get_db)):
    try:
        agent = await register_agent(
            db,
            agent_id=req.agent_id,
            name=req.name,
            capabilities=req.capabilities,
            description=req.description,
            owner_user_id=req.owner_user_id,
            endpoint_url=req.endpoint_url,
            public_key=req.public_key,
            initial_stake=Decimal(str(req.initial_stake)),
        )
        return {
            "agent_id": agent.agent_id,
            "did_identifier": agent.did_identifier,
            "status": agent.status.value,
            "registered_at": agent.registered_at.isoformat(),
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/{agent_id}/activate")
async def activate(agent_id: str, db: AsyncSession = Depends(get_db)):
    try:
        agent = await activate_agent(db, agent_id)
        return {"agent_id": agent.agent_id, "status": agent.status.value}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.post("/{agent_id}/tasks")
async def record_task(
    agent_id: str,
    req: RecordTaskRequest,
    db: AsyncSession = Depends(get_db),
):
    try:
        record = await record_agent_task(
            db,
            agent_id=agent_id,
            task_type=req.task_type,
            success=req.success,
            latency_ms=req.latency_ms,
            accuracy=req.accuracy,
            vit_earned=Decimal(str(req.vit_earned)),
            task_ref=req.task_ref,
            notes=req.notes,
        )
        return {
            "record_id": record.id,
            "task_type": record.task_type,
            "success": record.success,
            "proof_hash": record.proof_hash,
            "vit_earned": float(record.vit_earned),
            "recorded_at": record.recorded_at.isoformat(),
        }
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.post("/{agent_id}/credentials")
async def issue_cred(
    agent_id: str,
    req: IssueCredentialRequest,
    db: AsyncSession = Depends(get_db),
):
    try:
        cred = await issue_credential(
            db,
            agent_id=agent_id,
            credential_type=req.credential_type,
            issued_by=req.issued_by,
            valid_days=req.valid_days,
        )
        return {
            "credential_id": cred.id,
            "credential_type": cred.credential_type,
            "credential_hash": cred.credential_hash,
            "status": cred.status.value,
            "expires_at": cred.expires_at.isoformat() if cred.expires_at else None,
        }
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.post("/{agent_id}/payment-routes")
async def add_route(
    agent_id: str,
    req: PaymentRouteRequest,
    db: AsyncSession = Depends(get_db),
):
    try:
        route = await add_payment_route(
            db,
            agent_id=agent_id,
            route_type=req.route_type,
            recipient_address=req.recipient_address,
            split_pct=Decimal(str(req.split_pct)),
        )
        return {
            "route_id": route.id,
            "route_type": route.route_type,
            "recipient_address": route.recipient_address,
            "split_pct": float(route.split_pct),
        }
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
