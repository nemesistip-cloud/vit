"""app/modules/blockchain/analytics.py — Blockchain network analytics engine.

Provides aggregated metrics for:
  - Network health (validators, stakes, settlements)
  - Token economics (supply, burns, treasury, AI fund)
  - Validator performance distribution
  - Oracle accuracy and dispute rates
  - Consensus accuracy vs oracle outcomes
  - Staking market breakdown (per prediction type)
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Any, Dict, List

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.blockchain.models import (
    ConsensusPrediction,
    ConsensusStatus,
    MatchSettlement,
    OracleResult,
    UserStake,
    StakeStatus,
    ValidatorPrediction,
    ValidatorProfile,
    ValidatorStatus,
    PredictionResult,
    ValidatorSlashEvent,
)

logger = logging.getLogger(__name__)


async def get_network_stats(db: AsyncSession) -> Dict[str, Any]:
    """Full blockchain network statistics snapshot."""

    # Validator counts
    val_counts = await db.execute(
        select(ValidatorProfile.status, func.count(ValidatorProfile.id).label("cnt"))
        .group_by(ValidatorProfile.status)
    )
    val_by_status: Dict[str, int] = {r.status: r.cnt for r in val_counts}

    total_validators = sum(val_by_status.values())
    active_validators = val_by_status.get(ValidatorStatus.ACTIVE.value, 0)
    slashed_validators = val_by_status.get(ValidatorStatus.SLASHED.value, 0)
    suspended_validators = val_by_status.get(ValidatorStatus.SUSPENDED.value, 0)

    # Total staked VIT
    total_staked_res = await db.execute(
        select(func.sum(ValidatorProfile.stake_amount)).where(
            ValidatorProfile.status == ValidatorStatus.ACTIVE.value
        )
    )
    total_staked_vit = float(total_staked_res.scalar() or 0)

    # Average trust score
    avg_trust_res = await db.execute(
        select(func.avg(ValidatorProfile.trust_score)).where(
            ValidatorProfile.status == ValidatorStatus.ACTIVE.value
        )
    )
    avg_trust = float(avg_trust_res.scalar() or 0)

    # Consensus predictions
    consensus_counts = await db.execute(
        select(ConsensusPrediction.status, func.count(ConsensusPrediction.id).label("cnt"))
        .group_by(ConsensusPrediction.status)
    )
    cons_by_status: Dict[str, int] = {r.status: r.cnt for r in consensus_counts}
    total_consensus = sum(cons_by_status.values())

    # Settlement stats
    settlement_res = await db.execute(
        select(
            func.count(MatchSettlement.id).label("count"),
            func.sum(MatchSettlement.total_pool).label("total_pool"),
            func.sum(MatchSettlement.burn_amount).label("total_burned"),
            func.sum(MatchSettlement.treasury_fund).label("total_treasury"),
            func.sum(MatchSettlement.ai_fund).label("total_ai_fund"),
            func.sum(MatchSettlement.validator_fund).label("total_validator_fund"),
        )
    )
    srow = settlement_res.first()
    settlement_count = srow.count or 0
    total_pool_settled = float(srow.total_pool or 0)
    total_burned = float(srow.total_burned or 0)
    total_treasury = float(srow.total_treasury or 0)
    total_ai_fund = float(srow.total_ai_fund or 0)
    total_validator_fund = float(srow.total_validator_fund or 0)

    # Stake stats
    stake_counts = await db.execute(
        select(UserStake.status, func.count(UserStake.id).label("cnt"),
               func.sum(UserStake.stake_amount).label("total"))
        .group_by(UserStake.status)
    )
    stake_by_status: Dict[str, Dict] = {}
    for r in stake_counts:
        stake_by_status[r.status] = {"count": r.cnt, "total_amount": float(r.total or 0)}

    active_stakes = stake_by_status.get(StakeStatus.ACTIVE.value, {}).get("count", 0)
    active_stake_amount = stake_by_status.get(StakeStatus.ACTIVE.value, {}).get("total_amount", 0)

    # Oracle stats
    oracle_total_res = await db.execute(select(func.count(OracleResult.id)))
    oracle_accepted_res = await db.execute(
        select(func.count(OracleResult.id)).where(OracleResult.is_accepted == True)
    )
    oracle_disputed_res = await db.execute(
        select(func.count(OracleResult.id)).where(OracleResult.dispute_flag == True)
    )
    oracle_total = oracle_total_res.scalar() or 0
    oracle_accepted = oracle_accepted_res.scalar() or 0
    oracle_disputed = oracle_disputed_res.scalar() or 0

    # Slash events
    slash_count_res = await db.execute(select(func.count(ValidatorSlashEvent.id)))
    slash_count = slash_count_res.scalar() or 0
    slash_vol_res = await db.execute(select(func.sum(ValidatorSlashEvent.slash_amount)))
    slash_volume = float(slash_vol_res.scalar() or 0)

    # Validator prediction accuracy
    pred_accuracy_res = await db.execute(
        select(ValidatorPrediction.result, func.count(ValidatorPrediction.id).label("cnt"))
        .group_by(ValidatorPrediction.result)
    )
    pred_by_result: Dict[str, int] = {r.result: r.cnt for r in pred_accuracy_res}
    accurate = pred_by_result.get(PredictionResult.ACCURATE.value, 0)
    inaccurate = pred_by_result.get(PredictionResult.INACCURATE.value, 0)
    total_settled_preds = accurate + inaccurate
    accuracy_rate = round(accurate / max(total_settled_preds, 1), 4)

    # Staking market breakdown
    market_breakdown = await db.execute(
        select(UserStake.prediction, func.count(UserStake.id).label("cnt"),
               func.sum(UserStake.stake_amount).label("vol"))
        .group_by(UserStake.prediction)
    )
    markets: List[Dict] = [
        {"market": r.prediction, "count": r.cnt, "volume": float(r.vol or 0)}
        for r in market_breakdown
    ]

    return {
        "validators": {
            "total": total_validators,
            "active": active_validators,
            "slashed": slashed_validators,
            "suspended": suspended_validators,
            "pending": val_by_status.get(ValidatorStatus.PENDING.value, 0),
            "total_staked_vit": total_staked_vit,
            "avg_trust_score": round(avg_trust, 4),
        },
        "consensus": {
            "total": total_consensus,
            "open": cons_by_status.get(ConsensusStatus.OPEN.value, 0),
            "locked": cons_by_status.get(ConsensusStatus.LOCKED.value, 0),
            "settled": cons_by_status.get(ConsensusStatus.SETTLED.value, 0),
            "voided": cons_by_status.get(ConsensusStatus.VOIDED.value, 0),
        },
        "settlements": {
            "count": settlement_count,
            "total_pool_vit": total_pool_settled,
            "total_burned_vit": total_burned,
            "total_treasury_vit": total_treasury,
            "total_ai_fund_vit": total_ai_fund,
            "total_validator_fund_vit": total_validator_fund,
        },
        "oracle": {
            "total_reports": oracle_total,
            "accepted": oracle_accepted,
            "disputed": oracle_disputed,
            "acceptance_rate": round(oracle_accepted / max(oracle_total, 1), 4),
        },
        "staking": {
            "active_stakes": active_stakes,
            "active_stake_amount_vit": active_stake_amount,
            "by_status": stake_by_status,
            "market_breakdown": markets,
        },
        "slashing": {
            "total_events": slash_count,
            "total_volume_vit": slash_volume,
        },
        "validator_accuracy": {
            "accurate": accurate,
            "inaccurate": inaccurate,
            "total_settled": total_settled_preds,
            "accuracy_rate": accuracy_rate,
        },
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }


async def get_validator_leaderboard(db: AsyncSession, limit: int = 20) -> List[Dict]:
    """Top validators ranked by influence score."""
    result = await db.execute(
        select(ValidatorProfile)
        .where(ValidatorProfile.status == ValidatorStatus.ACTIVE.value)
        .order_by(ValidatorProfile.influence_score.desc())
        .limit(limit)
    )
    validators = result.scalars().all()

    board = []
    for rank, v in enumerate(validators, 1):
        accuracy = (
            round(v.accurate_predictions / v.total_predictions, 4)
            if v.total_predictions > 0 else 0.0
        )
        board.append({
            "rank": rank,
            "validator_id": v.id,
            "user_id": v.user_id,
            "stake_amount": float(v.stake_amount),
            "trust_score": float(v.trust_score),
            "influence_score": float(v.influence_score),
            "total_predictions": v.total_predictions,
            "accurate_predictions": v.accurate_predictions,
            "accuracy_rate": accuracy,
            "joined_at": v.joined_at.isoformat() if v.joined_at else None,
            "last_active": v.last_active.isoformat() if v.last_active else None,
        })
    return board


async def get_token_economics(db: AsyncSession) -> Dict[str, Any]:
    """Token supply, burn, and distribution economics snapshot."""
    from app.modules.wallet.models import Wallet, Currency
    from sqlalchemy import and_

    # Total VIT held in wallets
    total_vit_res = await db.execute(
        select(func.sum(Wallet.vitcoin_balance))
    )
    total_vit_in_wallets = float(total_vit_res.scalar() or 0)

    # Total burned
    burn_res = await db.execute(select(func.sum(MatchSettlement.burn_amount)))
    total_burned = float(burn_res.scalar() or 0)

    # Recent settlements (last 30 days)
    cutoff = datetime.now(timezone.utc) - timedelta(days=30)
    recent_burn_res = await db.execute(
        select(func.sum(MatchSettlement.burn_amount)).where(
            MatchSettlement.settled_at >= cutoff
        )
    )
    recent_burn = float(recent_burn_res.scalar() or 0)

    # Slash burns (50% of slash volume)
    slash_burn_res = await db.execute(select(func.sum(ValidatorSlashEvent.slash_amount)))
    slash_volume = float(slash_burn_res.scalar() or 0)
    slash_burn = slash_volume * 0.5

    total_effective_burn = total_burned + slash_burn

    return {
        "circulation": {
            "total_vit_in_wallets": total_vit_in_wallets,
            "total_staked_vit": (
                float((await db.execute(
                    select(func.sum(ValidatorProfile.stake_amount)).where(
                        ValidatorProfile.status == ValidatorStatus.ACTIVE.value
                    )
                )).scalar() or 0)
            ),
        },
        "burns": {
            "settlement_burns_total": total_burned,
            "slash_burns_total": slash_burn,
            "total_effective_burn": total_effective_burn,
            "last_30d_burn": recent_burn,
        },
        "treasury": {
            "total_accumulated": float(
                (await db.execute(select(func.sum(MatchSettlement.treasury_fund)))).scalar() or 0
            ),
            "total_ai_fund": float(
                (await db.execute(select(func.sum(MatchSettlement.ai_fund)))).scalar() or 0
            ),
        },
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }
