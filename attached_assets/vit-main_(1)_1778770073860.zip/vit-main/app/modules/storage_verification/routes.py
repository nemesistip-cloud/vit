"""Storage Verification Routes — content registry, proofs, challenges, attestations."""
from __future__ import annotations

from decimal import Decimal
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import get_db
from app.modules.storage_verification.service import (
    attest_availability,
    get_storage_stats,
    issue_challenge,
    register_content,
    respond_to_challenge,
    submit_storage_proof,
)

router = APIRouter(prefix="/api/storage", tags=["storage-verification"])


class RegisterContentRequest(BaseModel):
    content_hash: str
    content_type: str
    ipfs_cid: Optional[str] = None
    arweave_id: Optional[str] = None
    description: Optional[str] = None
    size_bytes: Optional[int] = None
    owner_user_id: Optional[int] = None
    ref_type: Optional[str] = None
    ref_id: Optional[int] = None
    is_public: bool = True


class SubmitProofRequest(BaseModel):
    content_hash: str
    node_address: str
    proof_data: str
    proof_type: str = "merkle"
    prover_user_id: Optional[int] = None
    stake_locked: float = 10.0
    validity_days: int = 30


class IssueChallengeRequest(BaseModel):
    proof_id: int
    challenger_user_id: Optional[int] = None
    response_hours: int = 24


class RespondChallengeRequest(BaseModel):
    response_data: str


class AttestRequest(BaseModel):
    content_hash: str
    attestor_user_id: int
    available: bool = True
    latency_ms: Optional[int] = None


@router.get("/stats")
async def storage_stats(db: AsyncSession = Depends(get_db)):
    return await get_storage_stats(db)


@router.post("/content/register")
async def register(req: RegisterContentRequest, db: AsyncSession = Depends(get_db)):
    entry = await register_content(
        db,
        content_hash=req.content_hash,
        content_type=req.content_type,
        ipfs_cid=req.ipfs_cid,
        arweave_id=req.arweave_id,
        description=req.description,
        size_bytes=req.size_bytes,
        owner_user_id=req.owner_user_id,
        ref_type=req.ref_type,
        ref_id=req.ref_id,
        is_public=req.is_public,
    )
    return {
        "id": entry.id,
        "content_hash": entry.content_hash,
        "ipfs_cid": entry.ipfs_cid,
        "content_type": entry.content_type,
        "replication_factor": entry.replication_factor,
        "registered_at": entry.registered_at.isoformat(),
    }


@router.post("/proofs/submit")
async def submit_proof(req: SubmitProofRequest, db: AsyncSession = Depends(get_db)):
    try:
        proof = await submit_storage_proof(
            db,
            content_hash=req.content_hash,
            node_address=req.node_address,
            proof_data=req.proof_data,
            proof_type=req.proof_type,
            prover_user_id=req.prover_user_id,
            stake_locked=Decimal(str(req.stake_locked)),
            validity_days=req.validity_days,
        )
        return {
            "proof_id": proof.id,
            "proof_hash": proof.proof_hash,
            "status": proof.status.value,
            "stake_locked": float(proof.stake_locked),
            "expires_at": proof.expires_at.isoformat() if proof.expires_at else None,
            "submitted_at": proof.submitted_at.isoformat(),
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/challenges/issue")
async def issue_storage_challenge(req: IssueChallengeRequest, db: AsyncSession = Depends(get_db)):
    try:
        challenge = await issue_challenge(
            db,
            proof_id=req.proof_id,
            challenger_user_id=req.challenger_user_id,
            response_hours=req.response_hours,
        )
        return {
            "challenge_id": challenge.id,
            "challenge_nonce": challenge.challenge_nonce,
            "status": challenge.status.value,
            "response_deadline": challenge.response_deadline.isoformat(),
            "issued_at": challenge.issued_at.isoformat(),
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/challenges/{challenge_id}/respond")
async def respond_to_storage_challenge(
    challenge_id: int,
    req: RespondChallengeRequest,
    db: AsyncSession = Depends(get_db),
):
    try:
        challenge = await respond_to_challenge(db, challenge_id, req.response_data)
        return {
            "challenge_id": challenge.id,
            "status": challenge.status.value,
            "valid": challenge.status.value == "resolved_valid",
            "slash_amount": float(challenge.slash_amount),
            "resolved_at": challenge.resolved_at.isoformat() if challenge.resolved_at else None,
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/attestations")
async def attest(req: AttestRequest, db: AsyncSession = Depends(get_db)):
    try:
        att = await attest_availability(
            db,
            content_hash=req.content_hash,
            attestor_user_id=req.attestor_user_id,
            available=req.available,
            latency_ms=req.latency_ms,
        )
        return {
            "attestation_id": att.id,
            "available": att.available,
            "latency_ms": att.latency_ms,
            "attested_at": att.attested_at.isoformat(),
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
