"""VIT DID Engine — generates DID documents and issues Verifiable Credentials.

DID format:
  did:vit:{uuid4}          → human user
  did:vit:agent:{name}     → autonomous agent node
  did:vit:network          → VIT network issuer (pseudo-DID, not stored)

W3C DID Core compliant document structure.
"""
from __future__ import annotations

import hashlib
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.did.models import VITIdentity, VerifiableCredential

_CONTEXT = ["https://www.w3.org/ns/did/v1", "https://w3id.org/security/v2"]
_VC_CONTEXT = ["https://www.w3.org/2018/credentials/v1", "https://vit.network/credentials/v1"]
_NETWORK_ISSUER = "did:vit:network"


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _make_did_user(user_id: int) -> str:
    """Deterministic user DID from user_id."""
    seed = f"vit-user-{user_id}"
    uid = uuid.uuid5(uuid.NAMESPACE_URL, seed)
    return f"did:vit:{uid}"


def _make_did_agent(agent_name: str) -> str:
    """Deterministic agent DID from agent name."""
    return f"did:vit:agent:{agent_name}"


def _build_did_document(did: str, subject_type: str, label: str) -> dict[str, Any]:
    """Construct a W3C-compliant DID document."""
    key_id = f"{did}#key-1"
    return {
        "@context": _CONTEXT,
        "id": did,
        "controller": did,
        "verificationMethod": [
            {
                "id": key_id,
                "type": "Ed25519VerificationKey2020",
                "controller": did,
                "publicKeyMultibase": f"z{hashlib.sha256(did.encode()).hexdigest()[:44]}",
            }
        ],
        "authentication": [key_id],
        "assertionMethod": [key_id],
        "service": [
            {
                "id": f"{did}#vit-network",
                "type": "VITNetworkService",
                "serviceEndpoint": "https://vit.network/api/did",
            }
        ],
        "metadata": {
            "subjectType": subject_type,
            "label": label,
            "network": "vit-mainnet",
            "created": _utcnow().isoformat(),
        },
    }


def _build_credential(
    credential_type: str,
    subject_did: str,
    claims: dict[str, Any],
    valid_days: Optional[int] = None,
) -> dict[str, Any]:
    """Build a W3C Verifiable Credential payload."""
    now = _utcnow()
    vc: dict[str, Any] = {
        "@context": _VC_CONTEXT,
        "type": ["VerifiableCredential", credential_type],
        "id": f"urn:vit:vc:{uuid.uuid4()}",
        "issuer": _NETWORK_ISSUER,
        "issuanceDate": now.isoformat(),
        "credentialSubject": {
            "id": subject_did,
            **claims,
        },
    }
    if valid_days:
        vc["expirationDate"] = (now + timedelta(days=valid_days)).isoformat()
    return vc


# ── Public API ──────────────────────────────────────────────────────────────


async def get_or_create_user_identity(
    user_id: int,
    display_name: str,
    db: AsyncSession,
) -> VITIdentity:
    """Fetch or create the DID identity for a human user."""
    did = _make_did_user(user_id)
    res = await db.execute(select(VITIdentity).where(VITIdentity.did == did))
    identity = res.scalar_one_or_none()
    if identity:
        return identity

    doc = _build_did_document(did, "user", display_name)
    identity = VITIdentity(
        did=did,
        subject_type="user",
        user_id=user_id,
        did_document=doc,
    )
    db.add(identity)
    await db.flush()
    return identity


async def get_or_create_agent_identity(
    agent_name: str,
    db: AsyncSession,
) -> VITIdentity:
    """Fetch or create the DID identity for an agent node."""
    did = _make_did_agent(agent_name)
    res = await db.execute(select(VITIdentity).where(VITIdentity.did == did))
    identity = res.scalar_one_or_none()
    if identity:
        return identity

    doc = _build_did_document(did, "agent", agent_name)
    identity = VITIdentity(
        did=did,
        subject_type="agent",
        agent_name=agent_name,
        did_document=doc,
    )
    db.add(identity)
    await db.flush()
    return identity


async def resolve_did(did: str, db: AsyncSession) -> Optional[VITIdentity]:
    """Resolve a DID to its VITIdentity document."""
    res = await db.execute(
        select(VITIdentity).where(VITIdentity.did == did, VITIdentity.active == True)
    )
    return res.scalar_one_or_none()


async def issue_credential(
    identity_id: str,
    credential_type: str,
    claims: dict[str, Any],
    db: AsyncSession,
    valid_days: Optional[int] = None,
) -> VerifiableCredential:
    """Issue a Verifiable Credential to a VITIdentity."""
    res = await db.execute(select(VITIdentity).where(VITIdentity.id == identity_id))
    identity = res.scalar_one_or_none()
    if not identity:
        raise ValueError(f"Identity {identity_id} not found")

    vc_payload = _build_credential(credential_type, identity.did, claims, valid_days)
    expires_at = None
    if valid_days:
        expires_at = _utcnow() + timedelta(days=valid_days)

    vc = VerifiableCredential(
        identity_id=identity_id,
        credential_type=credential_type,
        credential=vc_payload,
        expires_at=expires_at,
    )
    db.add(vc)
    await db.flush()
    return vc


async def get_active_credentials(
    identity_id: str, db: AsyncSession
) -> list[VerifiableCredential]:
    """Return all non-revoked, non-expired credentials for an identity."""
    now = _utcnow()
    res = await db.execute(
        select(VerifiableCredential).where(
            VerifiableCredential.identity_id == identity_id,
            VerifiableCredential.revoked == False,
        )
    )
    all_vcs = res.scalars().all()
    return [
        vc for vc in all_vcs
        if vc.expires_at is None or vc.expires_at.replace(tzinfo=timezone.utc) > now
    ]


async def list_all_identities(
    subject_type: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
    db: AsyncSession = None,
) -> list[VITIdentity]:
    """List active identities, optionally filtered by type."""
    q = select(VITIdentity).where(VITIdentity.active == True)
    if subject_type:
        q = q.where(VITIdentity.subject_type == subject_type)
    q = q.order_by(VITIdentity.created_at.desc()).limit(limit).offset(offset)
    res = await db.execute(q)
    return res.scalars().all()
