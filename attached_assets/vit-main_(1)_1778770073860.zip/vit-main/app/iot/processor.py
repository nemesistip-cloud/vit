"""app/iot/processor.py — IoT event processor and WebSocket broadcaster."""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List

from fastapi import WebSocket

logger = logging.getLogger(__name__)


class IoTStreamManager:
    """Manages all connected WebSocket clients for the IoT live stream."""

    def __init__(self) -> None:
        self._clients: List[WebSocket] = []

    async def connect(self, ws: WebSocket) -> None:
        await ws.accept()
        self._clients.append(ws)
        logger.info("[iot] client connected (total=%d)", len(self._clients))

    def disconnect(self, ws: WebSocket) -> None:
        if ws in self._clients:
            self._clients.remove(ws)
        logger.info("[iot] client disconnected (total=%d)", len(self._clients))

    async def broadcast(self, payload: Dict[str, Any]) -> None:
        """Send a JSON payload to every connected client."""
        dead: List[WebSocket] = []
        for ws in list(self._clients):
            try:
                await ws.send_json(payload)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws)

    @property
    def client_count(self) -> int:
        return len(self._clients)


# Module-level singleton — shared by router and agents
iot_stream = IoTStreamManager()


async def store_and_broadcast(
    source: str,
    event_type: str,
    payload: Dict[str, Any],
    match_id: int | None = None,
) -> int:
    """Persist an IoT event to the database and broadcast it over WebSocket.

    Returns the new event's database ID.
    """
    from app.db.database import AsyncSessionLocal
    from app.db.models import IoTEvent

    async with AsyncSessionLocal() as db:
        event = IoTEvent(
            source=source,
            event_type=event_type,
            match_id=match_id,
            payload=payload,
            processed=False,
        )
        db.add(event)
        await db.commit()
        await db.refresh(event)
        event_id = event.id

    broadcast_payload = {
        "event_id":   event_id,
        "source":     source,
        "event_type": event_type,
        "match_id":   match_id,
        "payload":    payload,
        "ts":         datetime.now(timezone.utc).isoformat(),
    }
    await iot_stream.broadcast(broadcast_payload)
    logger.debug("[iot] stored event_id=%d type=%s source=%s", event_id, event_type, source)
    return event_id


async def mark_processed(event_id: int, agent_response: str | None = None) -> None:
    """Mark an IoT event as processed (optionally with AI response text)."""
    from app.db.database import AsyncSessionLocal
    from app.db.models import IoTEvent
    from sqlalchemy import update

    async with AsyncSessionLocal() as db:
        await db.execute(
            update(IoTEvent)
            .where(IoTEvent.id == event_id)
            .values(
                processed=True,
                processed_at=datetime.now(timezone.utc),
                agent_response=agent_response,
            )
        )
        await db.commit()
